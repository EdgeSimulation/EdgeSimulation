/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.network_power.datacenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
//import org.cloudbus.cloudsim.examples.power.Constants;
import org.cloudbus.cloudsim.network.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.network.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.util.ExecutionTimeMeasurer;  

//Katya: these four classes are imported in order to read the migration Fog file
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;


/**
 * A VM migration policy that uses community based algorithm to decide the destination host for migration
 * 
 */
public class Network_PowerVmMigrationPolicyFogCommunityBased extends Network_PowerVmAllocationPolicyMigrationAbstract {
	String algorithm; // LB or SC
	VmAllocationPolicy originalPolicy;
	Network_PowerDatacenter dc;
	
	private String forLog;
	
	private enum UL{
		LOW, MEDIUM, HIGH
	}
		
	private double high=0.75, medium=0.25;
	
	private List<FogCommunity> communities;
	
	//Katya: copied from Test_FatTree_Example_Power_CommunityMigration
	private class ParamsMigr {
		private double timeStamp;
		private int cloudservice, VM, comm;
		ParamsMigr() {}
	}
	
	//Katya: this list has the migrations from Fog communities read from the migrations.txt file
	private List<ParamsMigr> paramsMigrList;
	private ListIterator<ParamsMigr> pmlIterator; // we are going to read from the file in time steps so no need to start from top every time


	public Network_PowerVmMigrationPolicyFogCommunityBased(
			List<? extends Host> hostList,
			Network_PowerVmSelectionPolicy vmSelectionPolicy,
			String originalPolicy, String parameterName,
			String algorithm,
			String fileName) {
		super(hostList, vmSelectionPolicy);
		
		this.originalPolicy=createOriginalPolicyInstance(hostList, originalPolicy, parameterName);
		this.algorithm=algorithm.toUpperCase();
		communities=new ArrayList<FogCommunity>();
		
		// Katya: read the FOG migration file
		try {
			loadFogMobilityFile(fileName);
			pmlIterator=paramsMigrList.listIterator();
		} catch (InstantiationException | IllegalAccessException | IOException e) {
			e.printStackTrace();
		}

	}
	
	//Katya: this function is called within the constructor and creates a list with the Fog migrations that have to be performed during the simulation
	protected void loadFogMobilityFile(String name) throws IOException, InstantiationException, IllegalAccessException{
		BufferedReader in = new BufferedReader(new FileReader("./log/"+name));
		int cont=0;		
		String QueVM;
		this.paramsMigrList=new ArrayList<ParamsMigr>();
		
		String line = in.readLine(); // <-- read whole line
		// We want to skip the first 3 lines
		line = in.readLine(); // <-- read whole line
		line = in.readLine(); // <-- read whole line
		line = in.readLine(); // <-- read whole line
		
		while (line != null)
		{
			ParamsMigr p=new ParamsMigr();
			StringTokenizer tk = new StringTokenizer(line);
		 	cont=tk.countTokens();
			p.timeStamp = Double.parseDouble(tk.nextToken()); // <-- read single word on line and parse to int
			QueVM = tk.nextToken();
			p.cloudservice = Integer.parseInt(QueVM.substring(0,QueVM.indexOf('-')));
			p.VM = Integer.parseInt(QueVM.substring(QueVM.indexOf('-'),QueVM.length())); // <-- read single word on line and parse to int
			p.comm = Integer.parseInt(tk.nextToken()); // <-- read single word on line and parse to int
			
			this.paramsMigrList.add(p);
			
			line = in.readLine(); // <-- read whole line
		}
		in.close();
	}

	
	private VmAllocationPolicy createOriginalPolicyInstance(List<? extends Host> hostList, String vmAllocationPolicyName, String parameterName){
		VmAllocationPolicy vmAllocationPolicy = null;
		Network_PowerVmSelectionPolicy vmSelectionPolicy = null;

		double parameter = 0;
		if (!parameterName.isEmpty()) {
			parameter = Double.valueOf(parameterName);
		}
		if (vmAllocationPolicyName.equals("iqr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationInterQuartileRange(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("mad")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationMedianAbsoluteDeviation(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationLocalRegression(
					hostList,
					vmSelectionPolicy,
					parameter,
					100,  //error in Constants.SCHEDULING_INTERVAL (?()
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lrr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationLocalRegressionRobust(
					hostList,
					vmSelectionPolicy,
					parameter,
					100,  //error in Constants.SCHEDULING_INTERVAL (?()
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("thr")) {
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					parameter);
		} 
		else {
			System.out.println("Unknown VM allocation policy: " + vmAllocationPolicyName);
			System.exit(0);
		}
		return vmAllocationPolicy;

	}

	@Override
	protected boolean isHostOverUtilized(Network_PowerHost host) {
		return ((Network_PowerVmAllocationPolicyMigrationAbstract) originalPolicy).isHostOverUtilized(host);
	}

	/**
	 * Optimize allocation of the VMs according to current utilization.
	 * 
	 * @param vmList the vm list
	 * 
	 * @return the array list< hash map< string, object>>
	 */
	@Override
	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) {
		List<Map<String, Object>> migrationMap = new LinkedList<Map<String, Object>>();

		saveAllocation();
		
		// step 1: find the destination community for each VM that needs to be migrated at this timestamp
		// use the migrations recorded from the input file, based on current time
		double currentTime = CloudSim.clock();
		if (currentTime < 1) //still start of simulation, do nothing
			return null; 
		double delta = 2;
		
		int destinationCommunity=Integer.MAX_VALUE;
		int fogService = Integer.MAX_VALUE;
		
		// find the time stamp in the migrations list that is currentTime +- delta
		while (pmlIterator.hasNext()){
			ParamsMigr pm=pmlIterator.next();
			if ((pm.timeStamp <= currentTime + delta) && (pm.timeStamp >= currentTime - delta)){
				// for all rows that are for this time interval, do the migration
				destinationCommunity=pm.comm;
				fogService=pm.cloudservice-1;
				
				// find the broker that has name Broker_fogService
				String brokerName="Broker_" + Integer.toString(fogService);

				DatacenterBroker tempBroker = null;
				Iterator<SimEntity> entityIterator = CloudSim.getEntityList().iterator();
				// Let's find the broker
				while (entityIterator.hasNext()) {
					SimEntity tempEntity= entityIterator.next();
					//System.out.println("Entity's name: " + tempEntity.getName());
					if (tempEntity.getName().equals(brokerName)) {
						tempBroker = (DatacenterBroker)CloudSim.getEntity(tempEntity.getName());
						break;
					}
				}
				// now we have the broker, we need to find all VMs that belong to this broker and try to migrate them
				
				for (int vmIndex=0; vmIndex<tempBroker.getVmList().size(); vmIndex++){
					
					Vm vm=tempBroker.getVmList().get(vmIndex);
					
					Network_PowerHost orig_host = (Network_PowerHost)vm.getHost();
					List<Network_PowerHost> excludedHosts = new LinkedList<Network_PowerHost>();
					excludedHosts.add(orig_host);
					Network_PowerHost allocatedHost = findHostForVm(vm, new HashSet<Network_PowerHost>(excludedHosts), destinationCommunity);
					if (allocatedHost!=null)
						if (this.allocateHostForVm(vm, allocatedHost)) {
							//Katya: More bandwidth for the original host
							orig_host.setMaxBandwidthConsumedOnMigration(vm, orig_host.getVmList().size());
							//orig_host.setMaxBandwidthConsumedOnMigration_Host_orig(vm,vmsToMigrate.size());
							//allocatedHost.vmCreate(vm);
							//Katya: More bandwidth for the destination host
							//allocatedHost.setMaxBandwidthConsumedOnMigration_Host_dest(vm, vmsToMigrate.size());
							Log.printConcatLine("VM #", vm.getId(), " allocated to host #", allocatedHost.getId());
			
							Map<String, Object> migrate = new HashMap<String, Object>();
							migrate.put("vm", vm);
							migrate.put("host", allocatedHost);
							migrationMap.add(migrate);
						}
						else Log.printLine("out "+forLog);
				}

			}
			if ((pm.timeStamp >= currentTime + delta)){ // no more lines from this time interval
				// go one step back with the iterator
				if (pmlIterator.hasPrevious())
					pmlIterator.previous();
				break;
			}
		}
		 
		
		restoreAllocation();

		return migrationMap;
	}
	
	
	
	/*
	 * Main idea: use the check for migration from the vmallocationpolicymigration, but change the choice for destination host
	 */
	//@Override	
	public Network_PowerHost findHostForVm(Vm vm, Set<? extends Host> excludedHosts, int destinationCommunity) {
		Network_PowerHost nph=null;
		
		// Sonja start
		if (CloudSim.clock()>0)
		if (vm.getCloudletScheduler().getCloudletExecList().size()==0)
			if (vm.getCloudletScheduler().getCloudletPausedList().size()==0)
				if (vm.getCloudletScheduler().getCloudletWaitingList().size()==0)
					return null;
		// Sonja end
		// original implementation first fit
//					for (Network_PowerHost host : this.<Network_PowerHost> getHostList()) {
//						if (host.isSuitableForVm(vm)) {
//							return host;
//						}
//					}
		
		// change implementation to community based

		dc=((Network_PowerDatacenter) CloudSim.getEntity("Datacenter_0"));

		if (communities.isEmpty()) // first call
			createCommunitiesSUMO(dc.getHostList().size(),dc);
			//createCommunities(dc.getHostList().size(),dc);
		
		// a host must be found in the destination community (location based migration for fog computing)
		// if no space available in destination community then go up the hierarchy of communities
		// and find the first one that will accommodate the fog service
		
		// step 1: the host may already be in that community, if so just return null
			int source = Integer.MAX_VALUE;
			// find the min community of the host
			for (int i=0; i<communities.size(); i++){
				if (communities.get(i).isMember(vm.getHost())){
					source=i;
					break;
				}	
			}
			if (source==destinationCommunity) {
				Log.printLine(CloudSim.clock() +" Migration from to identical community: VM #"+vm.getId()+" host #"+vm.getHost().getId()+" dest community: "+destinationCommunity);
				return nph; //null
			}
		// step 2: make the destination community potential community
			
			// create a list of hosts that belong to the same community
			List<Host> potentialHostList=communities.get(destinationCommunity).getMembers();
			
			// remove hosts that can not accommodate the VM
			List<Host> finalPotentialList= new ArrayList<Host>();
			for (int i=0; i<potentialHostList.size(); i++)
				if (potentialHostList.get(i).isSuitableForVm(vm) && 
						!excludedHosts.contains(potentialHostList.get(i)) )
					finalPotentialList.add(potentialHostList.get(i));
		// step 3: try to do the placement
			nph = (Network_PowerHost) dynamicVMplacement (finalPotentialList, vm, algorithm);
			
			int dist = 3; Host randomH=communities.get(destinationCommunity).getMembers().get(0);
			int size=communities.get(communities.size()-1).getMembers().size();
			// find distance between source and destination communities
			for (int j=communities.size()-1; j>source && j>destinationCommunity; j--){
				// find the smallest community that contains hosts from both source and destination
				if (communities.get(j).isMember(vm.getHost()) && communities.get(j).isMember(randomH)){
					if (size > communities.get(j).getMembers().size()){
						dist--;
						size=communities.get(j).getMembers().size();
					}
				}
			}			
			if (nph==null) // no viable placement has been found, write that in the log
				forLog=CloudSim.clock() + " Attempt to migrate failed: VM #"+vm.getId()+" source community #"+source+" destination community #"+destinationCommunity+" distance from host: "+dist;	
			else
				forLog=CloudSim.clock() + " Optimal migration of: VM #"+vm.getId()+" source community #"+source+" to host #"+nph.getId() +" destination community #"+destinationCommunity;	
			Log.printLine(forLog);
			
		return nph;
	}

	
	// from community based implementation
	protected class Vector{
		private float pes=0,ram=0,bw=0;
		
		public Vector(float p, float r, float b){
			pes=p;	ram=r;	bw=b;
		}
		void setPes(float v){pes=v;}
		void setRam(float v){ram=v;}
		void setBw(float v){bw=v;}
		
		float getPes(){return pes;}
		float getRam(){return ram;}
		float getBw(){return bw;}
		
		float max(){
			return Math.max(Math.max(pes,ram),bw);
		}
		
		double magnitude(){
			return Math.sqrt(pes*pes+ram*ram+bw*bw);
		}
		
		double sum(Vector v){
			Vector s=new Vector(pes+v.pes,ram+v.ram,bw+v.bw);
			return s.magnitude();
		}
	}
	
	protected Vector computeRUV (Host esteHost) {
		
		return	new Vector(
					(float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size()
							)/esteHost.getNumberOfPes(),
					(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam(),
					((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw()
					);
	}
	
	protected Vector computeRRV (Vm esteVm, Host target) {
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes(),
				(float)esteVm.getRam()/target.getRam(),
				(long)esteVm.getBw()/target.getBw()
			);
	}

	protected Vector computeRIVpm (Host esteHost) {
		
		float sum=((float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size())/esteHost.getNumberOfPes() +
				(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam() +
				((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw())/3;
		 return new Vector( 
				(float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size())/esteHost.getNumberOfPes() - sum,
				(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam() - sum,
				((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw() - sum
			);
	}
		
	protected Vector computeRIVvm (Vm esteVm, Host target) {
		
		float sum=((float)esteVm.getNumberOfPes()/target.getNumberOfPes() +
					(float)esteVm.getRam()/target.getRam() +
					(long)esteVm.getBw()/target.getBw())/3;
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes() - sum,
				(float)esteVm.getRam()/target.getRam() - sum,
				(long)esteVm.getBw()/target.getBw() - sum
			);
	}
	
	protected int VMtriangle(Vm vm, Host target){
		// return the triangle in which vm's RRV lies
		Vector RRV=computeRRV(vm,target);
		
		if (RRV.pes >= RRV.ram){ 
			if (RRV.ram >= RRV.bw)
				return 5; //CM
			else if (RRV.pes >= RRV.bw)
					return 0; //CI
		} 
		if (RRV.ram >= RRV.pes){ 
			if (RRV.pes >= RRV.bw)
				return 4; //MC
			else if (RRV.ram >= RRV.bw)
				return 3; //MI
		}
		if (RRV.bw >= RRV.pes){
			if (RRV.pes >= RRV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected int CRT(int T){
		// return the CRT triangle of triangle T
		if (T==0) return 3;
		else if (T==1) return 4;
		else if (T==2) return 5;
		else if (T==3) return 0;
		else if (T==4) return 1;
		else if (T==5) return 2;
		else return -1;
	}
	
	protected List<Integer> firstTneighbor(int t){
		if (t==0) return Arrays.asList(5,1);
		else if (t==1) return Arrays.asList(2,0);
		else if (t==2) return Arrays.asList(1,3);
		else if (t==3) return Arrays.asList(2,4);
		else if (t==4) return Arrays.asList(3,5);
		else if (t==5) return Arrays.asList(0,4);
		else return Arrays.asList(-1,-1);
	}
	
	protected List<Integer> secondTneighbor(int t){
		if (t==0) return Arrays.asList(4,2);
		else if (t==1) return Arrays.asList(3,5);
		else if (t==2) return Arrays.asList(0,4);
		else if (t==3) return Arrays.asList(1,5);
		else if (t==4) return Arrays.asList(2,0);
		else if (t==5) return Arrays.asList(1,3);
		else return Arrays.asList(-1,-1);
	}
	
	protected int PMtriangle(Host target){
		// return the triangle in which PM's RUV lies
		Vector RUV=computeRUV(target);
		
		if (RUV.pes >= RUV.ram){ 
			if (RUV.ram >= RUV.bw)
				return 5; //CM
			else if (RUV.pes >= RUV.bw)
					return 0; //CI
		} 
		if (RUV.ram >= RUV.pes){ 
			if (RUV.pes >= RUV.bw)
				return 4; //MC
			else if (RUV.ram >= RUV.bw)
				return 3; //MI
		}
		if (RUV.bw >= RUV.pes){
			if (RUV.pes >= RUV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected List<UL> getOverallPMUtilization(List<Host> HostList){
//		1: if max(CPU;MEM; IO) >= HIGH then
//		2: Utilization level is HIGH;
//		3: else if max(CPU;MEM; IO) >= MEDIUM then
//		4: Utilization level is MEDIUM;
//		5: else
//		6: Utilization level is LOW;
//		7: end if
		
		ArrayList<UL> utilizationLevel=new ArrayList<UL>();
		
		for (int i=0; i < HostList.size(); i++) {
			Vector RUV=computeRUV(HostList.get(i));
			if (RUV.max() >= high)
					utilizationLevel.add(UL.HIGH);
			else if (RUV.max() >= medium)
					utilizationLevel.add(UL.MEDIUM);
			else utilizationLevel.add(UL.LOW);
		}
		return utilizationLevel;
	}
	
	public Host dynamicVMplacement (List<Host> HostList, Vm vm, String lower) {
//	1: PotentialPMlist   GetPotentialPMs(VM; goal);
//	5: for all PM in PotentialPMlist do
//	6: Compute the vector addition of RIVs of PM and VM;
//	7: M   magnitude of the above addition vector;
//	8: end for
//	9: Mark PM with the lowest M as the host for the VM;
		
		List<Host> potentialPMlist=null;
		if (lower.equals("SC"))
			potentialPMlist=getPotentialPMsSC(vm,HostList);
		else if (lower.equals("LB"))
			potentialPMlist=getPotentialPMsLB(vm,HostList);

		if (potentialPMlist.size()==0){ // no available PM
			// add new host
			for (int i=0; i<HostList.size(); i++)
				if (computeRUV(HostList.get(i)).magnitude()==0)
					if (HostList.get(i).isSuitableForVm(vm))
						potentialPMlist.add(HostList.get(i));
			if (potentialPMlist.size()==0) // no available PM
				return null;
		}
		
		List<Double> M = new ArrayList<>();
		for (int i=0; i<potentialPMlist.size(); i++)
		{
			Host host=potentialPMlist.get(i);
			Vector RIVpm=computeRIVpm(host);
			Vector RIVvm=computeRIVvm(vm,host);
			M.add(RIVpm.sum(RIVvm));
		}
		// find PM with lowest M
			double minM=M.get(0);
			int minIndex=0;
			for (int i=1; i<M.size(); i++){
				if (minM>M.get(i)){
					minM=M.get(i);
					minIndex=i;
				}
			}
		// place VM on this host
			if (potentialPMlist.get(minIndex).isSuitableForVm(vm)) {
				int who = HostList.indexOf(potentialPMlist.get(minIndex));
				return HostList.get(who);
			}
			else return null;
	}
	
	protected List<Host> getPotentialPMsSC(Vm vm, List<Host> hostList){
		List<Host> high_potentialPMlist = new ArrayList<Host>();
		List<Host> medium_potentialPMlist = new ArrayList<Host>();
		List<Host> low_potentialPMlist = new ArrayList<Host>();
		List<Host> other_potentialPMlist = new ArrayList<Host>();
		
		List<UL> ul=getOverallPMUtilization(hostList);
		
		// do HIGH, MEDIUM and LOW, other and new at once in different lists, choose which one to use in the end
		for (int i=0; i < hostList.size(); i++){
			// find all PMs that have tVM=tPM
			Host host=hostList.get(i);
			// if host empty or host full skip
			Vector RUV=computeRUV(host);
			if (RUV.magnitude()==0) continue;
			if (RUV.getBw()==1) continue;
			if (RUV.getPes()==1) continue;
			if (RUV.getRam()==1) continue;
			// check if PM has enough resources to host the VM
			if (host.isSuitableForVm(vm))
			{
				other_potentialPMlist.add(host);
				
				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host); 
				if (tVM==tPM){
					if (ul.get(i)==UL.HIGH){
						high_potentialPMlist.add(host);
					}else if (ul.get(i)==UL.MEDIUM){
						medium_potentialPMlist.add(host);
					}else if (ul.get(i)==UL.LOW)
						low_potentialPMlist.add(host);
				}else{
					// two first T neighbors with HIGH
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.HIGH)
							medium_potentialPMlist.add(host);
					}
					
					// two first T neighbors with MEDIUM
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.MEDIUM)
							low_potentialPMlist.add(host);
					}
					// two second T neighbors with HIGH
					if (secondTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.HIGH)
							low_potentialPMlist.add(host);
					}
				}
			}
		}
		
		// return the first list with size>0 in order high, medium, low, other, new
			if (high_potentialPMlist.size()>0)
				return high_potentialPMlist;
			else if (medium_potentialPMlist.size()>0)
				return medium_potentialPMlist;
			else if (low_potentialPMlist.size()>0)
				return low_potentialPMlist;
//			else if (other_potentialPMlist.size()>0)
				return other_potentialPMlist;		
	}
	
	protected List<Host> getPotentialPMsLB(Vm vm, List<Host> hostList){
		
		List<Host> high_potentialPMlist = new ArrayList<Host>();
		List<Host> medium_potentialPMlist = new ArrayList<Host>();
		List<Host> low_potentialPMlist = new ArrayList<Host>();
		List<Host> other_potentialPMlist = new ArrayList<Host>();

		List<UL> ul=getOverallPMUtilization(hostList);
		
		//LOW, MEDIUM, HIGH
		for (int i=0; i < hostList.size(); i++){
			// find all PMs that have tVM=tPM
			Host host=hostList.get(i);
			// if host empty of host full skip
			Vector RUV=computeRUV(host);
			if (RUV.magnitude()==0) continue;
			if (RUV.getBw()==1) continue;
			if (RUV.getPes()==1) continue;
			if (RUV.getRam()==1) continue;
			// check if PM has enough resources to host the VM
			if (host.isSuitableForVm(vm))
			{
				other_potentialPMlist.add(host);

				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host); 
				if (tVM==tPM){
					if (ul.get(i)==UL.LOW){
						low_potentialPMlist.add(host);
					} else
					if (ul.get(i)==UL.MEDIUM){
						medium_potentialPMlist.add(host);
					} else
					if (ul.get(i)==UL.HIGH)
						high_potentialPMlist.add(host);
	
	
				}
				else{
					// two first T neighbors with LOW
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							medium_potentialPMlist.add(host);
					}
					// two first T neighbors with MEDIUM
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.MEDIUM)
							high_potentialPMlist.add(host);
					}
					// two second T neighbors with LOW
					if (secondTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							high_potentialPMlist.add(host);
					}
	
				}
			}
		}

			// return the first list with size>0 in order low, medium, high, other, new
			if (low_potentialPMlist.size()>0)
				return low_potentialPMlist;
			else if (medium_potentialPMlist.size()>0)
				return medium_potentialPMlist;
			else if (high_potentialPMlist.size()>0)
				return high_potentialPMlist;
//			else if (other_potentialPMlist.size()>0)
				return other_potentialPMlist;			
	}

	public void createCommunitiesSUMO(int numhost, NetworkDatacenter dc){
		
		
		// 9 edge switches, 3 agg switch, 1 root switch
		// 9 communities in first level one per each switch with ids 0-8
		communities=new ArrayList<FogCommunity>();
		
		
		FogCommunity c=new FogCommunity();
		int edgeSwitchHostNo=(int) (NetworkConstants.EdgeSwitchPort-1);
		for (int i=0; i<dc.getHostList().size(); i++) {
			if (i>0 & Math.floorMod(i,edgeSwitchHostNo)==0){
				communities.add(c);
				c=new FogCommunity();
			}
			c.addMember(dc.getHostList().get(i));
		}
		communities.add(c);
		
		// per agg sw 
		int count=NetworkConstants.Agg_LEVEL;
		int aggSwitchLevelHostNo=(int) ((NetworkConstants.EdgeSwitchPort-1)*(NetworkConstants.AggSwitchPort-1));
		for (int i=0; i < count; i++){
			c=new FogCommunity();
			for (int j=0; j < aggSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*aggSwitchLevelHostNo+j));
			communities.add(c);
		}
		
		// fourth per root sw
		int countR=NetworkConstants.ROOT_LEVEL;
		int rootSwitchLevelHostNo=(int) ((NetworkConstants.EdgeSwitchPort-1)*(NetworkConstants.AggSwitchPort-1)*(NetworkConstants.RootSwitchPort));
		for (int i=0; i < countR; i++){
			c=new FogCommunity();
			for (int j=0; j < rootSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*rootSwitchLevelHostNo+j));
			communities.add(c);
		}

		// end: all hosts
		 c=new FogCommunity();
		for (Host hs : dc.getHostList()) {
			c.addMember(hs);
		}
		communities.add(c);
	}

	
	public void createCommunities(int numhost, NetworkDatacenter dc){
		
		// 3 level FatTree
		
		// 8 edge switches, 4 agg switch, 4 root switch
		// 8 communities in first level one per each switch with ids 0-7
		communities=new ArrayList<FogCommunity>();
		
		
		// we don't need separate hosts as separate communities
		
		// first each single host separately
//		for (Host hs : dc.getHostList()) {
//			Community c=new Community();
//			c.addMember(hs);
//			communities.add(c);
//		}
		
		// second per edge switch (numhost/numedgeswitches) (edge_switch_ports - 2 members per switch)
		FogCommunity c=new FogCommunity();
		int edgeSwitchHostNo=(int) (NetworkConstants.EdgeSwitchPort-2);
		for (int i=0; i<dc.getHostList().size(); i++) {
			if (i>0 & Math.floorMod(i,edgeSwitchHostNo)==0){
				communities.add(c);
				c=new FogCommunity();
			}
			c.addMember(dc.getHostList().get(i));
		}
		communities.add(c);
		
		// third per agg sw 
		int count=NetworkConstants.Agg_LEVEL;
		int aggSwitchLevelHostNo=edgeSwitchHostNo*2;
		for (int i=0; i < count; i++){
			c=new FogCommunity();
			for (int j=0; j < aggSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*aggSwitchLevelHostNo+j));
			communities.add(c);
		}
		
		// fourth per root sw
		int countR=NetworkConstants.ROOT_LEVEL;
		int rootSwitchLevelHostNo=aggSwitchLevelHostNo*4;
		for (int i=0; i < countR; i++){
			c=new FogCommunity();
			for (int j=0; j < rootSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*rootSwitchLevelHostNo+j));
			communities.add(c);
		}

		// end: all hosts
		 c=new FogCommunity();
		for (Host hs : dc.getHostList()) {
			c.addMember(hs);
		}
		communities.add(c);
	}

}

class FogCommunity {  // group of hosts only
	private List<Host> hostMembers;
	private int no_members; // number of members

	FogCommunity(){
		no_members=0;
		hostMembers=new ArrayList<Host>();
	}
	void addMember(Host nh){
		if (!hostMembers.contains(nh)){
			hostMembers.add(nh);
			no_members+=1;
		}
	}
	boolean isMember(Host nh){
		return hostMembers.contains(nh);
	}
	List<Host> getMembers(){
		return hostMembers;
	}	
}
