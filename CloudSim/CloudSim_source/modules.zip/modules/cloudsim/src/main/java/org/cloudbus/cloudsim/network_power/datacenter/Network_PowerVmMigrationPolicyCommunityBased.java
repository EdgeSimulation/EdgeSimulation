/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.network_power.datacenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.examples.power.Constants;
import org.cloudbus.cloudsim.network.datacenter.NetworkConstants;

/**
 * A VM migration policy that uses community based algorithm to decide the destination host for migration
 * 
 */
public class Network_PowerVmMigrationPolicyCommunityBased extends Network_PowerVmAllocationPolicyMigrationAbstract {
	String algorithm; // LB or SC
	VmAllocationPolicy originalPolicy;
	Network_PowerDatacenter dc;
	int ports;
	boolean flexible;
	
	private enum UL{
		LOW, MEDIUM, HIGH
	}
		
	private double high=0.75, medium=0.25;
	
	private List<Community> communities;


	public Network_PowerVmMigrationPolicyCommunityBased(
			List<? extends Host> hostList,
			Network_PowerVmSelectionPolicy vmSelectionPolicy,
			String originalPolicy, String parameterName,
			String algorithm,
			int ports_per_switch, 
			boolean flexibility) {
		super(hostList, vmSelectionPolicy);
		
		this.originalPolicy=createOriginalPolicyInstance(hostList, originalPolicy, parameterName);
		this.algorithm=algorithm.toUpperCase();
		ports=ports_per_switch;
		flexible=flexibility;
	}
	
	private VmAllocationPolicy createOriginalPolicyInstance(List<? extends Host> hostList, String vmAllocationPolicyName, String parameterName){
		VmAllocationPolicy vmAllocationPolicy = null;
		Network_PowerVmSelectionPolicy vmSelectionPolicy = null;

		double parameter = 0;
		if (!parameterName.isEmpty()) {
			parameter = Double.valueOf(parameterName);
		}
		if (vmAllocationPolicyName.equals("iqr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationInterQuartileRange(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("mad")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationMedianAbsoluteDeviation(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationLocalRegression(
					hostList,
					vmSelectionPolicy,
					parameter,
					Constants.SCHEDULING_INTERVAL,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lrr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationLocalRegressionRobust(
					hostList,
					vmSelectionPolicy,
					parameter,
					Constants.SCHEDULING_INTERVAL,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("thr")) {
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					parameter);
		} 
		else {
			System.out.println("Unknown VM allocation policy: " + vmAllocationPolicyName);
			System.exit(0);
		}
		return vmAllocationPolicy;

	}

	@Override
	protected boolean isHostOverUtilized(Network_PowerHost host) {
		return ((Network_PowerVmAllocationPolicyMigrationAbstract) originalPolicy).isHostOverUtilized(host);
	}

	/*
	 * Main idea: use the check for migration from the vmallocationpolicymigration, but change the choice for destination host
	 */
	@Override	
	public Network_PowerHost findHostForVm(Vm vm, Set<? extends Host> excludedHosts) {
		Network_PowerHost nph=null;
		
		// Sonja start
		if (CloudSim.clock()>0)
		if (vm.getCloudletScheduler().getCloudletExecList().size()==0)
			if (vm.getCloudletScheduler().getCloudletPausedList().size()==0)
				if (vm.getCloudletScheduler().getCloudletWaitingList().size()==0)
					return null;
		// Sonja end
		// original implementation first fit
//					for (Network_PowerHost host : this.<Network_PowerHost> getHostList()) {
//						if (host.isSuitableForVm(vm)) {
//							return host;
//						}
//					}
		// change implementation to community based
		
		// first step: find the target community
		createCommunities(ports);
		//find community by finding the community that accommodates all VMs that belong to the same CS
		List<Host> hosts_for_CS= new ArrayList<Host>();
		// find the cloud service
		String cs_uid=vm.getUid().substring(0, vm.getUid().indexOf("-")+1);
		
		dc=((Network_PowerDatacenter) CloudSim.getEntity("Datacenter_0"));
		// find all VMs that belong to the CS
		for (int i=0; i<dc.getVmList().size(); i++)
			if (dc.getVmList().get(i).getUid().contains(cs_uid))
				if (dc.getVmList().get(i).getHost() != null)
					hosts_for_CS.add(dc.getVmList().get(i).getHost());	
	
		
		if (!flexible) // a host must be found in the same community
		{
			// find the smallest community of all hosts
			int community_for_CS=Integer.MAX_VALUE;
			
			for (int i=0; i<communities.size(); i++){
				boolean allIN=true;
				for (int j=0; j<hosts_for_CS.size(); j++)
					if (!communities.get(i).isMember(hosts_for_CS.get(j))) {
						allIN=false;
						break;
					}
				if (allIN){
					community_for_CS=i;
					break;
				}
			}
			if (community_for_CS>=communities.size())
				community_for_CS=communities.size()-1;
			
			// second step: create a list of hosts that belong to the same community
			List<Host> potentialHostList=communities.get(community_for_CS).getMembers();
			// third step: remove hosts that can not accommodate the VM
			List<Host> finalPotentialList= new ArrayList<Host>();
			for (int i=0; i<potentialHostList.size(); i++)
				if (potentialHostList.get(i).isSuitableForVm(vm) && 
						!excludedHosts.contains(potentialHostList.get(i)) &&
						(getUtilizationOfCpuMips((Network_PowerHost) potentialHostList.get(i))!=0) )
					finalPotentialList.add(potentialHostList.get(i));
			// fourth step: try to do the placement
			return (Network_PowerHost) dynamicVMplacement (finalPotentialList, vm, algorithm);
		}
		else { // if a host can not be found in the same community then try bigger community
			// find the communities in which all hosts belong to
			List<Integer> community_for_CS= new ArrayList<Integer>();
			
			for (int i=0; i<communities.size()-1; i++){
				boolean allIN=true;
				for (int j=0; j<hosts_for_CS.size(); j++)
					if (!communities.get(i).isMember(hosts_for_CS.get(j))) {
						allIN=false;
						break;
					}
				if (allIN)
					community_for_CS.add(i);
			}
			community_for_CS.add(communities.size()-1);
			
			//community list is already sorted smallest to largest, so try one by one
			for (int c=0; c<community_for_CS.size(); c++) {
				// second step: create a list of hosts that belong to the same community
				List<Host> potentialHostList=communities.get(community_for_CS.get(c)).getMembers();
				// third step: remove hosts that can not accommodate the VM
				List<Host> finalPotentialList= new ArrayList<Host>();
				for (int i=0; i<potentialHostList.size(); i++)
					if (potentialHostList.get(i).isSuitableForVm(vm) && 
							!excludedHosts.contains(potentialHostList.get(i)) &&
							(getUtilizationOfCpuMips((Network_PowerHost) potentialHostList.get(i))!=0) )
						finalPotentialList.add(potentialHostList.get(i));
				// fourth step: try to do the placement
				nph = (Network_PowerHost) dynamicVMplacement (finalPotentialList, vm, algorithm);
				if (nph!=null){
					Log.printLine("Community level chosen "+c);
					break;
				}
			}
			return nph;			
		}
	}

	
	// from community based implementation
	protected class Vector{
		private float pes=0,ram=0,bw=0;
		
		public Vector(float p, float r, float b){
			pes=p;	ram=r;	bw=b;
		}
		void setPes(float v){pes=v;}
		void setRam(float v){ram=v;}
		void setBw(float v){bw=v;}
		
		float getPes(){return pes;}
		float getRam(){return ram;}
		float getBw(){return bw;}
		
		float max(){
			return Math.max(Math.max(pes,ram),bw);
		}
		
		double magnitude(){
			return Math.sqrt(pes*pes+ram*ram+bw*bw);
		}
		
		double sum(Vector v){
			Vector s=new Vector(pes+v.pes,ram+v.ram,bw+v.bw);
			return s.magnitude();
		}
	}
	
	protected Vector computeRUV (Host esteHost) {
		
		return	new Vector(
					(float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size()
							)/esteHost.getNumberOfPes(),
					(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam(),
					((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw()
					);
	}
	
	protected Vector computeRRV (Vm esteVm, Host target) {
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes(),
				(float)esteVm.getRam()/target.getRam(),
				(long)esteVm.getBw()/target.getBw()
			);
	}

	protected Vector computeRIVpm (Host esteHost) {
		
		float sum=((float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size())/esteHost.getNumberOfPes() +
				(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam() +
				((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw())/3;
		 return new Vector( 
				(float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size())/esteHost.getNumberOfPes() - sum,
				(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam() - sum,
				((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw() - sum
			);
	}
		
	protected Vector computeRIVvm (Vm esteVm, Host target) {
		
		float sum=((float)esteVm.getNumberOfPes()/target.getNumberOfPes() +
					(float)esteVm.getRam()/target.getRam() +
					(long)esteVm.getBw()/target.getBw())/3;
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes() - sum,
				(float)esteVm.getRam()/target.getRam() - sum,
				(long)esteVm.getBw()/target.getBw() - sum
			);
	}
	
	protected int VMtriangle(Vm vm, Host target){
		// return the triangle in which vm's RRV lies
		Vector RRV=computeRRV(vm,target);
		
		if (RRV.pes >= RRV.ram){ 
			if (RRV.ram >= RRV.bw)
				return 5; //CM
			else if (RRV.pes >= RRV.bw)
					return 0; //CI
		} 
		if (RRV.ram >= RRV.pes){ 
			if (RRV.pes >= RRV.bw)
				return 4; //MC
			else if (RRV.ram >= RRV.bw)
				return 3; //MI
		}
		if (RRV.bw >= RRV.pes){
			if (RRV.pes >= RRV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected int CRT(int T){
		// return the CRT triangle of triangle T
		if (T==0) return 3;
		else if (T==1) return 4;
		else if (T==2) return 5;
		else if (T==3) return 0;
		else if (T==4) return 1;
		else if (T==5) return 2;
		else return -1;
	}
	
	protected List<Integer> firstTneighbor(int t){
		if (t==0) return Arrays.asList(5,1);
		else if (t==1) return Arrays.asList(2,0);
		else if (t==2) return Arrays.asList(1,3);
		else if (t==3) return Arrays.asList(2,4);
		else if (t==4) return Arrays.asList(3,5);
		else if (t==5) return Arrays.asList(0,4);
		else return Arrays.asList(-1,-1);
	}
	
	protected List<Integer> secondTneighbor(int t){
		if (t==0) return Arrays.asList(4,2);
		else if (t==1) return Arrays.asList(3,5);
		else if (t==2) return Arrays.asList(0,4);
		else if (t==3) return Arrays.asList(1,5);
		else if (t==4) return Arrays.asList(2,0);
		else if (t==5) return Arrays.asList(1,3);
		else return Arrays.asList(-1,-1);
	}
	
	protected int PMtriangle(Host target){
		// return the triangle in which PM's RUV lies
		Vector RUV=computeRUV(target);
		
		if (RUV.pes >= RUV.ram){ 
			if (RUV.ram >= RUV.bw)
				return 5; //CM
			else if (RUV.pes >= RUV.bw)
					return 0; //CI
		} 
		if (RUV.ram >= RUV.pes){ 
			if (RUV.pes >= RUV.bw)
				return 4; //MC
			else if (RUV.ram >= RUV.bw)
				return 3; //MI
		}
		if (RUV.bw >= RUV.pes){
			if (RUV.pes >= RUV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected List<UL> getOverallPMUtilization(List<Host> HostList){
//		1: if max(CPU;MEM; IO) >= HIGH then
//		2: Utilization level is HIGH;
//		3: else if max(CPU;MEM; IO) >= MEDIUM then
//		4: Utilization level is MEDIUM;
//		5: else
//		6: Utilization level is LOW;
//		7: end if
		
		ArrayList<UL> utilizationLevel=new ArrayList<UL>();
		
		for (int i=0; i < HostList.size(); i++) {
			Vector RUV=computeRUV(HostList.get(i));
			if (RUV.max() >= high)
					utilizationLevel.add(UL.HIGH);
			else if (RUV.max() >= medium)
					utilizationLevel.add(UL.MEDIUM);
			else utilizationLevel.add(UL.LOW);
		}
		return utilizationLevel;
	}
	
	public Host dynamicVMplacement (List<Host> HostList, Vm vm, String lower) {
//	1: PotentialPMlist   GetPotentialPMs(VM; goal);
//	5: for all PM in PotentialPMlist do
//	6: Compute the vector addition of RIVs of PM and VM;
//	7: M   magnitude of the above addition vector;
//	8: end for
//	9: Mark PM with the lowest M as the host for the VM;
		
		List<Host> potentialPMlist=null;
		if (lower.equals("SC"))
			potentialPMlist=getPotentialPMsSC(vm,HostList);
		else if (lower.equals("LB"))
			potentialPMlist=getPotentialPMsLB(vm,HostList);

		if (potentialPMlist.size()==0){ // no available PM
			// add new host
			for (int i=0; i<HostList.size(); i++)
				if (computeRUV(HostList.get(i)).magnitude()==0)
					if (HostList.get(i).isSuitableForVm(vm))
						potentialPMlist.add(HostList.get(i));
			if (potentialPMlist.size()==0) // no available PM
				return null;
		}
		
		List<Double> M = new ArrayList<>();
		for (int i=0; i<potentialPMlist.size(); i++)
		{
			Host host=potentialPMlist.get(i);
			Vector RIVpm=computeRIVpm(host);
			Vector RIVvm=computeRIVvm(vm,host);
			M.add(RIVpm.sum(RIVvm));
		}
		// find PM with lowest M
			double minM=M.get(0);
			int minIndex=0;
			for (int i=1; i<M.size(); i++){
				if (minM>M.get(i)){
					minM=M.get(i);
					minIndex=i;
				}
			}
		// place VM on this host
			if (potentialPMlist.get(minIndex).isSuitableForVm(vm)) {
				int who = HostList.indexOf(potentialPMlist.get(minIndex));
				return HostList.get(who);
			}
			else return null;
	}
	
	protected List<Host> getPotentialPMsSC(Vm vm, List<Host> hostList){
		List<Host> high_potentialPMlist = new ArrayList<Host>();
		List<Host> medium_potentialPMlist = new ArrayList<Host>();
		List<Host> low_potentialPMlist = new ArrayList<Host>();
		List<Host> other_potentialPMlist = new ArrayList<Host>();
		
		List<UL> ul=getOverallPMUtilization(hostList);
		
		// do HIGH, MEDIUM and LOW, other and new at once in different lists, choose which one to use in the end
		for (int i=0; i < hostList.size(); i++){
			// find all PMs that have tVM=tPM
			Host host=hostList.get(i);
			// if host empty or host full skip
			Vector RUV=computeRUV(host);
			if (RUV.magnitude()==0) continue;
			if (RUV.getBw()==1) continue;
			if (RUV.getPes()==1) continue;
			if (RUV.getRam()==1) continue;
			// check if PM has enough resources to host the VM
			if (host.isSuitableForVm(vm))
			{
				other_potentialPMlist.add(host);
				
				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host); 
				if (tVM==tPM){
					if (ul.get(i)==UL.HIGH){
						high_potentialPMlist.add(host);
					}else if (ul.get(i)==UL.MEDIUM){
						medium_potentialPMlist.add(host);
					}else if (ul.get(i)==UL.LOW)
						low_potentialPMlist.add(host);
				}else{
					// two first T neighbors with HIGH
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.HIGH)
							medium_potentialPMlist.add(host);
					}
					
					// two first T neighbors with MEDIUM
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.MEDIUM)
							low_potentialPMlist.add(host);
					}
					// two second T neighbors with HIGH
					if (secondTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.HIGH)
							low_potentialPMlist.add(host);
					}
				}
			}
		}
		
		// return the first list with size>0 in order high, medium, low, other, new
			if (high_potentialPMlist.size()>0)
				return high_potentialPMlist;
			else if (medium_potentialPMlist.size()>0)
				return medium_potentialPMlist;
			else if (low_potentialPMlist.size()>0)
				return low_potentialPMlist;
//			else if (other_potentialPMlist.size()>0)
				return other_potentialPMlist;		
	}
	
	protected List<Host> getPotentialPMsLB(Vm vm, List<Host> hostList){
		
		List<Host> high_potentialPMlist = new ArrayList<Host>();
		List<Host> medium_potentialPMlist = new ArrayList<Host>();
		List<Host> low_potentialPMlist = new ArrayList<Host>();
		List<Host> other_potentialPMlist = new ArrayList<Host>();

		List<UL> ul=getOverallPMUtilization(hostList);
		
		//LOW, MEDIUM, HIGH
		for (int i=0; i < hostList.size(); i++){
			// find all PMs that have tVM=tPM
			Host host=hostList.get(i);
			// if host empty of host full skip
			Vector RUV=computeRUV(host);
			if (RUV.magnitude()==0) continue;
			if (RUV.getBw()==1) continue;
			if (RUV.getPes()==1) continue;
			if (RUV.getRam()==1) continue;
			// check if PM has enough resources to host the VM
			if (host.isSuitableForVm(vm))
			{
				other_potentialPMlist.add(host);

				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host); 
				if (tVM==tPM){
					if (ul.get(i)==UL.LOW){
						low_potentialPMlist.add(host);
					} else
					if (ul.get(i)==UL.MEDIUM){
						medium_potentialPMlist.add(host);
					} else
					if (ul.get(i)==UL.HIGH)
						high_potentialPMlist.add(host);
	
	
				}
				else{
					// two first T neighbors with LOW
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							medium_potentialPMlist.add(host);
					}
					// two first T neighbors with MEDIUM
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.MEDIUM)
							high_potentialPMlist.add(host);
					}
					// two second T neighbors with LOW
					if (secondTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							high_potentialPMlist.add(host);
					}
	
				}
			}
		}

			// return the first list with size>0 in order low, medium, high, other, new
			if (low_potentialPMlist.size()>0)
				return low_potentialPMlist;
			else if (medium_potentialPMlist.size()>0)
				return medium_potentialPMlist;
			else if (high_potentialPMlist.size()>0)
				return high_potentialPMlist;
//			else if (other_potentialPMlist.size()>0)
				return other_potentialPMlist;			
	}

	public void createCommunities(int ports_per_switch){
		// 3 level FatTree
		// total 1+ceil(noEdgeSw/(portsPerSwitch/2))+noEdgeSw+noServers
//		int no_comm=1+(int)Math.ceil(NetworkConstants.EDGE_LEVEL/(NetworkConstants.EdgeSwitchPort/2))+NetworkConstants.EDGE_LEVEL+numhost;
		communities=new ArrayList<Community>();
		// first each single host separately
		for (Host hs : this.getHostList()) {
			Community c=new Community();
			c.addMember(hs);
			communities.add(c);
		}
		
		// second per edge switch (per_switch_port/2 members per switch)
		Community c=new Community();
		for (int i=0; i<this.getHostList().size(); i++) {
			if (i>0 & Math.floorMod(i, ports_per_switch/2)==0){
				communities.add(c);
				c=new Community();
			}
			c.addMember(this.getHostList().get(i));
		}
		
		// third per group edge sw (edgesw/(ports/2) groups)
		int max=(ports_per_switch/2)*(ports_per_switch/2);
		for (int i=0; i<Math.ceil(NetworkConstants.EDGE_LEVEL/(ports_per_switch/2.0)); i++){
			c=new Community();
			for(int j=0; j<max; j++){
				if ((i*max+j)>=this.getHostList().size()) break;
				c.addMember(this.getHostList().get(i*max+j));
			}
			communities.add(c);
		}
		
		// fourth all hosts
		 c=new Community();
		for (Host hs : this.getHostList()) {
			c.addMember(hs);
		}
		communities.add(c);
	}

}

class Community {  // group of hosts only
	private List<Host> hostMembers;
	private int no_members; // number of members

	Community(){
		no_members=0;
		hostMembers=new ArrayList<Host>();
	}
	void addMember(Host nh){
		if (!hostMembers.contains(nh)){
			hostMembers.add(nh);
			no_members+=1;
		}
	}
	boolean isMember(Host nh){
		return hostMembers.contains(nh);
	}
	List<Host> getMembers(){
		return hostMembers;
	}	
}
