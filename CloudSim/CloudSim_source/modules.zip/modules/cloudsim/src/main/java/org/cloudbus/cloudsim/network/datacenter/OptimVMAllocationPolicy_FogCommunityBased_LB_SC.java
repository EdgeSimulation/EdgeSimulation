/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.network.datacenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

//Katya: these four classes are imported in order to read the migration Fog file
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
//import org.cloudbus.cloudsim.examples.PrintFile_K;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerDatacenter;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;


public class OptimVMAllocationPolicy_FogCommunityBased_LB_SC extends VmAllocationPolicy {

	private String method;
	
	/** Katya: The requested vm list. */
	private List<Vm> ALLvmList = null;

	private NetworkDatacenter dc;
	
	
	//private final Map<String, Host> vm_table = new HashMap<String, Host>();
	
	private enum UL{
		LOW, MEDIUM, HIGH
	}
		
	private double high=0.75, medium=0.25;
	
	private List<FogCommunity> communities;
	
	//Katya: copied from Test_FatTree_Example_Power_CommunityMigration
	private class ParamsInit {
		private double timeStamp, timeStop;
		private int cloudservice, VM, comm;
		ParamsInit() {}
	}
	
	//Katya: this list has the migrations from Fog communities read from the migrations.txt filen
	private List<ParamsInit> paramsInitList;

	//Katya: get the start and stop times of the vehicular mobility file
	public List<Double> start_times_SUMO = new ArrayList<Double>();
	public List<Double> stop_times_SUMO = new ArrayList<Double>();
	
	public OptimVMAllocationPolicy_FogCommunityBased_LB_SC(List<? extends Host> list, String m, String fileName) {
		super(list);
		method=m;
		
		// Katya: read the FOG migration file
		try {
			//loadFogMobilityFile(fileName);
			loadFogMobilityFile_SUMO(fileName);
		} catch (InstantiationException | IllegalAccessException | IOException e) {
			e.printStackTrace();
		}

	}
	
	//Katya: this function is called within the constructor and creates a list with the Fog allocations that have to be performed during the simulation
	protected void loadFogMobilityFile(String name) throws IOException, InstantiationException, IllegalAccessException{
		BufferedReader in = new BufferedReader(new FileReader("./log/"+name));
		int cont=0;		
		String QueVM;
		this.paramsInitList=new ArrayList<ParamsInit>();
		
		String line = in.readLine(); // <-- read whole line
		// We want to skip the first line
		line = in.readLine(); // <-- read whole line
		line = in.readLine(); // <-- read whole line
		line = in.readLine(); // <-- read whole line
		
		while (line != null)
		{
			ParamsInit p=new ParamsInit();
			StringTokenizer tk = new StringTokenizer(line);
		 	cont=tk.countTokens();
			p.timeStamp = Integer.parseInt(tk.nextToken()); // <-- read single word on line and parse to int
			QueVM = tk.nextToken();
			p.cloudservice = Integer.parseInt(QueVM.substring(0,QueVM.indexOf('-')));
			p.VM = Integer.parseInt(QueVM.substring(QueVM.indexOf('-'),QueVM.length())); // <-- read single word on line and parse to int
			p.comm = Integer.parseInt(tk.nextToken()); // <-- read single word on line and parse to int
			
			this.paramsInitList.add(p);
			
			line = in.readLine(); // <-- read whole line
		}
		in.close();
	}

	//Katya: this function is called within the constructor and creates a list with the Fog allocations from SUMO file
	protected void loadFogMobilityFile_SUMO(String name) throws IOException, InstantiationException, IllegalAccessException{
		BufferedReader in = new BufferedReader(new FileReader("./log/"+name));
		//int cont=0;		
		String QueVM;
		this.paramsInitList=new ArrayList<ParamsInit>();
		
		String line = in.readLine(); // <-- read whole line
		// We want to skip the first line
		line = in.readLine(); // <-- read whole line
		line = in.readLine(); // <-- read whole line
		line = in.readLine(); // <-- read whole line
		
		while (line != null)
		{
			ParamsInit p=new ParamsInit();
			StringTokenizer tk = new StringTokenizer(line);
		 	//cont=tk.countTokens();
			
			QueVM = tk.nextToken();
			p.cloudservice = Integer.parseInt(QueVM.substring(0,QueVM.indexOf('-')));
			p.VM = Integer.parseInt(QueVM.substring(QueVM.indexOf('-')+1,QueVM.length())); // <-- read single word on line and parse to int

			p.timeStamp = Double.parseDouble(tk.nextToken()); // <-- read single word on line and parse to int
			this.start_times_SUMO.add(p.timeStamp);
			p.timeStop = Double.parseDouble(tk.nextToken()); // <-- read single word on line and parse to int
			this.stop_times_SUMO.add(p.timeStop);
			p.comm = Integer.parseInt(tk.nextToken()); // <-- read single word on line and parse to int
			
			this.paramsInitList.add(p);
			
			line = in.readLine(); // <-- read whole line
		}
		in.close();
	}

	
	protected class Vector{
		private float pes=0,ram=0,bw=0;
		
		public Vector(float p, float r, float b){
			pes=p;	ram=r;	bw=b;
		}
		void setPes(float v){pes=v;}
		void setRam(float v){ram=v;}
		void setBw(float v){bw=v;}
		
		float getPes(){return pes;}
		float getRam(){return ram;}
		float getBw(){return bw;}
		
		float max(){
			return Math.max(Math.max(pes,ram),bw);
		}
		
		double magnitude(){
			return Math.sqrt(pes*pes+ram*ram+bw*bw);
		}
		
		double sum(Vector v){
			Vector s=new Vector(pes+v.pes,ram+v.ram,bw+v.bw);
			return s.magnitude();
		}
	}
	
	protected Vector computeRUV (Host esteHost) {
		
		return	new Vector(
					(float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size()
							)/esteHost.getNumberOfPes(),
					(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam(),
					((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw()
					);
	}

	protected Vector computeRUVcom (FogCommunity c) {
		
		//total resources - use capacity methods
		FogAllItems cap=c.getCapacityAllItems();
		FogAllItems tot=c.getTotalAllItems();
				
		return	new Vector(
					(float)(cap.CapacityPes-tot.TotalPes)/cap.CapacityPes,
					(float)(cap.CapacityRam-tot.TotalRam)/cap.CapacityRam,
					((long)cap.CapacityBw-tot.TotalBw)/cap.CapacityBw
					);
	}
	
	
	protected Vector computeRRV (Vm esteVm, Host target) {
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes(),
				(float)esteVm.getRam()/target.getRam(),
				(long)esteVm.getBw()/target.getBw()
			);
	}

	protected Vector computeRIVpm (Host esteHost) {
		
		float sum=((float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size())/esteHost.getNumberOfPes() +
				(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam() +
				((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw())/3;
		 return new Vector( 
				(float)(esteHost.getNumberOfPes()-((VmSchedulerSpaceShared) esteHost.getVmScheduler()).getFreePes().size())/esteHost.getNumberOfPes() - sum,
				(float)(esteHost.getRam()-esteHost.getRamProvisioner().getAvailableRam())/esteHost.getRam() - sum,
				((long)esteHost.getBw()-esteHost.getBwProvisioner().getAvailableBw())/esteHost.getBw() - sum
			);
	}
	
	protected Vector computeRIVcom (FogCommunity c) {
		
		// free resources - use total methods
		
		//total resources - use capacity methods
		FogAllItems cap=c.getCapacityAllItems();
		FogAllItems tot=c.getTotalAllItems();
		
		float sum=((float)(cap.CapacityPes-tot.TotalPes)/cap.CapacityPes +
				(float)(cap.CapacityRam-tot.TotalRam)/cap.CapacityRam +
				((long)cap.CapacityBw-tot.TotalBw)/cap.CapacityBw)/3;
		 return new Vector( 
				(float)(cap.CapacityPes-tot.TotalPes)/cap.CapacityPes - sum,
				(float)(cap.CapacityRam-tot.TotalRam)/cap.CapacityRam - sum,
				((long)cap.CapacityBw-tot.TotalBw)/cap.CapacityBw - sum
			);
	}
	
	protected Vector computeRIVvm (Vm esteVm, Host target) {
		
		float sum=((float)esteVm.getNumberOfPes()/target.getNumberOfPes() +
					(float)esteVm.getRam()/target.getRam() +
					(long)esteVm.getBw()/target.getBw())/3;
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes() - sum,
				(float)esteVm.getRam()/target.getRam() - sum,
				(long)esteVm.getBw()/target.getBw() - sum
			);
	}
	
	protected int VMtriangle(Vm vm, Host target){
		// return the triangle in which vm's RRV lies
		Vector RRV=computeRRV(vm,target);
		
		if (RRV.pes >= RRV.ram){ 
			if (RRV.ram >= RRV.bw)
				return 5; //CM
			else if (RRV.pes >= RRV.bw)
					return 0; //CI
		} 
		if (RRV.ram >= RRV.pes){ 
			if (RRV.pes >= RRV.bw)
				return 4; //MC
			else if (RRV.ram >= RRV.bw)
				return 3; //MI
		}
		if (RRV.bw >= RRV.pes){
			if (RRV.pes >= RRV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected int CRT(int T){
		// return the CRT triangle of triangle T
		if (T==0) return 3;
		else if (T==1) return 4;
		else if (T==2) return 5;
		else if (T==3) return 0;
		else if (T==4) return 1;
		else if (T==5) return 2;
		else return -1;
	}
	
	protected List<Integer> firstTneighbor(int t){
		if (t==0) return Arrays.asList(5,1);
		else if (t==1) return Arrays.asList(2,0);
		else if (t==2) return Arrays.asList(1,3);
		else if (t==3) return Arrays.asList(2,4);
		else if (t==4) return Arrays.asList(3,5);
		else if (t==5) return Arrays.asList(0,4);
		else return Arrays.asList(-1,-1);
	}
	
	protected List<Integer> secondTneighbor(int t){
		if (t==0) return Arrays.asList(4,2);
		else if (t==1) return Arrays.asList(3,5);
		else if (t==2) return Arrays.asList(0,4);
		else if (t==3) return Arrays.asList(1,5);
		else if (t==4) return Arrays.asList(2,0);
		else if (t==5) return Arrays.asList(1,3);
		else return Arrays.asList(-1,-1);
	}
	
	protected int PMtriangle(Host target){
		// return the triangle in which PM's RUV lies
		Vector RUV=computeRUV(target);
		
		if (RUV.pes >= RUV.ram){ 
			if (RUV.ram >= RUV.bw)
				return 5; //CM
			else if (RUV.pes >= RUV.bw)
					return 0; //CI
		} 
		if (RUV.ram >= RUV.pes){ 
			if (RUV.pes >= RUV.bw)
				return 4; //MC
			else if (RUV.ram >= RUV.bw)
				return 3; //MI
		}
		if (RUV.bw >= RUV.pes){
			if (RUV.pes >= RUV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected List<UL> getOverallPMUtilization(List<Host> HostList){
//		1: if max(CPU;MEM; IO) >= HIGH then
//		2: Utilization level is HIGH;
//		3: else if max(CPU;MEM; IO) >= MEDIUM then
//		4: Utilization level is MEDIUM;
//		5: else
//		6: Utilization level is LOW;
//		7: end if
		
		ArrayList<UL> utilizationLevel=new ArrayList<UL>();
		
		for (int i=0; i < HostList.size(); i++) {
			Vector RUV=computeRUV(HostList.get(i));
			if (RUV.max() >= high)
					utilizationLevel.add(UL.HIGH);
			else if (RUV.max() >= medium)
					utilizationLevel.add(UL.MEDIUM);
			else utilizationLevel.add(UL.LOW);
		}
		return utilizationLevel;
	}
	
	public Host dynamicVMplacement (List<Host> HostList, Vm vm, String lower) {
//	1: PotentialPMlist   GetPotentialPMs(VM; goal);
//	5: for all PM in PotentialPMlist do
//	6: Compute the vector addition of RIVs of PM and VM;
//	7: M   magnitude of the above addition vector;
//	8: end for
//	9: Mark PM with the lowest M as the host for the VM;
		
		List<Host> potentialPMlist=null;
		if (lower.equals("SC"))
			potentialPMlist=getPotentialPMsSC(vm,HostList);
		else if (lower.equals("LB"))
			potentialPMlist=getPotentialPMsLB(vm,HostList);

		if (potentialPMlist.size()==0){ // no available PM
			// add new host
			for (int i=0; i<HostList.size(); i++)
				if (computeRUV(HostList.get(i)).magnitude()==0)
					if (HostList.get(i).isSuitableForVm(vm))
						potentialPMlist.add(HostList.get(i));
			if (potentialPMlist.size()==0) // no available PM
				return null;
		}
		
		List<Double> M = new ArrayList<>();
		for (int i=0; i<potentialPMlist.size(); i++)
		{
			Host host=potentialPMlist.get(i);
			Vector RIVpm=computeRIVpm(host);
			Vector RIVvm=computeRIVvm(vm,host);
			M.add(RIVpm.sum(RIVvm));
		}
		// find PM with lowest M
			double minM=M.get(0);
			int minIndex=0;
			for (int i=1; i<M.size(); i++){
				if (minM>M.get(i)){
					minM=M.get(i);
					minIndex=i;
				}
			}
		// place VM on this host
			boolean allocated = 														
					allocateHostForVm(vm, potentialPMlist.get(minIndex));
			if (allocated) {
				int who = HostList.indexOf(vm.getHost());
				return HostList.get(who);
			}
			else return null;
	}
	
	protected List<Host> getPotentialPMsSC(Vm vm, List<Host> hostList){
//		2: T = CRT of the triangle in which the VM lies;
//		3: PotentialPMlist  ;;
//		17: start from HIGH util to LOW
//		18: PotentialPMlist = PMs in T which have HIGH utilization;
//		19: Remove PMs from PotentialPMlist which can not support the VM;
//		20: if PotentialPMlist= empty; then
//			21: PotentialPMlist = (PMs in T which have MEDIUM
//				utilization) union (PMs in T’s first order neighbors which have
//					HIGH utilization);
//			22: Remove PMs from PotentialPMlist which can not support the VM;
//		23: end if
//		24: if PotentialPMlist=empty; then
//			25: PotentialPMlist = (PMs in T which have LOW utilization) union (PMs
//				in T’s first order neighbors which have MEDIUM
//					utilization) union (PMs in T’s second order neighbors which
//						have HIGH utilization)
//			26: Remove PMs from PotentialPMlist which can not support the VM;
//		27: end if
//		29: if PotentialPMlist is Empty then
//			30: put all the PMs which were not checked above into PotentialPMlist;
//			31: Remove PMs from PotentialPMlist which can not support the VM;
//		32: end if
		
//		2: if PotentialPMlist empty then
//		3: Introduce new PM;
//		4: end if
		
//		33: return PotentialPMlist;
		
		List<Host> high_potentialPMlist = new ArrayList<Host>();
		List<Host> medium_potentialPMlist = new ArrayList<Host>();
		List<Host> low_potentialPMlist = new ArrayList<Host>();
		List<Host> other_potentialPMlist = new ArrayList<Host>();
		
		List<UL> ul=getOverallPMUtilization(hostList);
		
		// do HIGH, MEDIUM and LOW, other and new at once in different lists, choose which one to use in the end
		for (int i=0; i < hostList.size(); i++){
			// find all PMs that have tVM=tPM
			Host host=hostList.get(i);
			// if host empty or host full skip
			Vector RUV=computeRUV(host);
			if (RUV.magnitude()==0) continue;
			if (RUV.getBw()==1) continue;
			if (RUV.getPes()==1) continue;
			if (RUV.getRam()==1) continue;
			// check if PM has enough resources to host the VM
			if (host.isSuitableForVm(vm))
			{
				other_potentialPMlist.add(host);
				
				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host); 
				if (tVM==tPM){
					if (ul.get(i)==UL.HIGH){
						high_potentialPMlist.add(host);
					}else if (ul.get(i)==UL.MEDIUM){
						medium_potentialPMlist.add(host);
					}else if (ul.get(i)==UL.LOW)
						low_potentialPMlist.add(host);
				}else{
					// two first T neighbors with HIGH
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.HIGH)
							medium_potentialPMlist.add(host);
					}
					
					// two first T neighbors with MEDIUM
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.MEDIUM)
							low_potentialPMlist.add(host);
					}
					// two second T neighbors with HIGH
					if (secondTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.HIGH)
							low_potentialPMlist.add(host);
					}
				}
			}
		}
		
		// return the first list with size>0 in order high, medium, low, other, new
			if (high_potentialPMlist.size()>0)
				return high_potentialPMlist;
			else if (medium_potentialPMlist.size()>0)
				return medium_potentialPMlist;
			else if (low_potentialPMlist.size()>0)
				return low_potentialPMlist;
//			else if (other_potentialPMlist.size()>0)
				return other_potentialPMlist;		
	}
	
	protected List<Host> getPotentialPMsLB(Vm vm, List<Host> hostList){
//		2: T = CRT of the triangle in which the VM lies;
//		3: PotentialPMlist  ;;
//		5: /* start from LOW util to HIGH util as shown in Figure 9*/
//		6: PotentialPMlist   fPMs in T which have LOW utilizationg;
//		7: Remove PMs from PotentialPMlist which can not support the VM;
//		8: if PotentialPMlist= ; then
//			9: PotentialPMlist fPMs in T which have MEDIUM
//				utilizationg[fPMs in T’s two first order neighbors which
//				have LOW utilizationg;
//			10: Remove PMs from PotentialPMlist which can not support the VM;
//		11: end if
//		12: if PotentialPMlist= ; then
//			13: PotentialPMlist fPMs in T which have HIGH
//				utilizationg[fPMs in T’s two first order neighbors which
//				have MEDIUM utilizationg[fPMs in T’s two second order
//				neighbors which have LOW utilizationg;
//			14: Remove PMs from PotentialPMlist which can not support the VM;
//		15: end if
//		29: if PotentialPMlist is Empty then
//			30: put all the PMs which were not checked above into PotentialPMlist;
//			31: Remove PMs from PotentialPMlist which can not support the VM;
//		32: end if
//		33: return PotentialPMlist;
		
		List<Host> high_potentialPMlist = new ArrayList<Host>();
		List<Host> medium_potentialPMlist = new ArrayList<Host>();
		List<Host> low_potentialPMlist = new ArrayList<Host>();
		List<Host> other_potentialPMlist = new ArrayList<Host>();

		List<UL> ul=getOverallPMUtilization(hostList);
		
		//LOW, MEDIUM, HIGH
		for (int i=0; i < hostList.size(); i++){
			// find all PMs that have tVM=tPM
			Host host=hostList.get(i);
			// if host empty of host full skip
			Vector RUV=computeRUV(host);
			if (RUV.magnitude()==0) continue;
			if (RUV.getBw()==1) continue;
			if (RUV.getPes()==1) continue;
			if (RUV.getRam()==1) continue;
			// check if PM has enough resources to host the VM
			if (host.isSuitableForVm(vm))
			{
				other_potentialPMlist.add(host);

				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host); 
				if (tVM==tPM){
					if (ul.get(i)==UL.LOW){
						low_potentialPMlist.add(host);
					} else
					if (ul.get(i)==UL.MEDIUM){
						medium_potentialPMlist.add(host);
					} else
					if (ul.get(i)==UL.HIGH)
						high_potentialPMlist.add(host);
	
	
				}
				else{
					// two first T neighbors with LOW
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							medium_potentialPMlist.add(host);
					}
					// two first T neighbors with MEDIUM
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.MEDIUM)
							high_potentialPMlist.add(host);
					}
					// two second T neighbors with LOW
					if (secondTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							high_potentialPMlist.add(host);
					}
	
				}
			}
		}

			// return the first list with size>0 in order low, medium, high, other, new
			if (low_potentialPMlist.size()>0)
				return low_potentialPMlist;
			else if (medium_potentialPMlist.size()>0)
				return medium_potentialPMlist;
			else if (high_potentialPMlist.size()>0)
				return high_potentialPMlist;
//			else if (other_potentialPMlist.size()>0)
				return other_potentialPMlist;			
	}

	
	public boolean INIoptimizeAllocation_FogCommunityBased (List<Host> HostList, List<Vm> Vmlist, String method, int location) {
		if (dc == null) { // first call
			dc=((Network_PowerDatacenter) CloudSim.getEntity("Datacenter_0"));
			createCommunities(dc.getHostList().size(), dc);
		}

		int edgeSwitchHostNo=(int) (NetworkConstants.EdgeSwitchPort-1);

		Host theHost=null;
		// megaVM = sum (Vmlist)
		long size = 0; //image size
		int mips = 0;
		long bw = 0;
		String vmm = ""; //VMM name
		int coresVM = 0;
		int ramVM =0;
		for (int i=0; i<Vmlist.size(); i++){
			size+=Vmlist.get(i).getSize();
			mips+=Vmlist.get(i).getMips();
			bw+=Vmlist.get(i).getBw();
			vmm=Vmlist.get(i).getVmm();
			coresVM+=Vmlist.get(i).getNumberOfPes();
			ramVM+=Vmlist.get(i).getRam();
		}
		Vm megaVM=new Vm(0, 0, mips, coresVM , ramVM, bw, size, vmm, new CloudletSchedulerSpaceShared());
		
		//create sorted list of communities
		List<FogCommunity> sortedComm = new ArrayList<FogCommunity>();
		
		// level by level approach - according to location, adding hierarchical communities
				
		// megaHost = sum (hosts in community)

		// check 1st level: location; 
		// 2nd level: location/2 + no of edge switches; 
		// 3rd level: location/4 + no of edge switches + no of agg switches
		// last resort: all hosts
		
		if (location > communities.size()-1)
			System.out.println("problem !!!");
		
		//int indexes[]= new int[3];
		int indexes[]= new int[2];
		indexes[0]=location;
		//indexes[1]=location/2+dc.getEdgeSwitch().size();
		indexes[1]=location/3+9;
		//indexes[2]=location/4+dc.getEdgeSwitch().size()+dc.getEdgeSwitch().size()/2;
		
		
		
		
		for (int i=0; i<indexes.length; i++){
			int j=indexes[i];
			Host h=communities.get(j).getMegaHost();
			// if community is full do not add
			if (!communities.get(j).full()){
				// if community is too small do not add
				if (h.isSuitableForVm(megaVM))
					sortedComm.add(communities.get(j));
			}
		}
		// add last community = all fog
		sortedComm.add(communities.get(communities.size()-1));
		
		//try community one by one
		for (int j=0; j<sortedComm.size(); j++){
			List<Host> shortHostList=sortedComm.get(j).getMembers();
			boolean placed=true;

			for (int i=0; i < Vmlist.size(); i++){
				 theHost=dynamicVMplacement(shortHostList,Vmlist.get(i),method);
				if (theHost==null){
					// placement failed
					// cloud service failed
					placed=false;
					// revert placements
					for (int k=0; k < i; k++){
						//update used resources of host
						deallocateHostForVm(Vmlist.get(k));
					}
					break;
				}
			}
			
			if (placed){
				// update log
			//	PrintFile_K.AddtoFile("","Timestamp" +"\t\t"+ "Host ID" +"\t\t"+ "Community ID" +"\t\t" + "no. of VMs" + "\t\t" + "VM list (CS no. - VM no.)" + "\t\t" +
				//		"VM RAM" +  "\t\t" + "VMcores" + "\t\t" + "VM MIPS" + "\t\t" + "VMsize");
				
				String forLog;
				for (int k=0; k < Vmlist.size(); k++){
					Vm vm=Vmlist.get(k);
					int brkr = vm.getUserId()-(dc.Switchlist.size()+3);
					/*PrintFile_K.AddtoFile("",CloudSim.clock() + ":\t\t\t" + 
							vm.getHost().getId() + "\t\t\t" +
							sortedComm.get(j).getID() + "\t\t\t" +  
							vm.getHost().getVmList().size() +
							"\t\t\t" +  brkr + "-" + vm.getId() + 
							"\t\t\t" + vm.getRam() +
							"\t\t\t" + vm.getNumberOfPes() + 
							"\t\t\t" + vm.getMips());*/
					forLog=CloudSim.clock() + " Initial placement of: VM #"+vm.getId()+" ("+vm.getNumberOfPes()+"/"+vm.getCurrentAllocatedRam()+")"+" source community #"+location+" to host #"+vm.getHost().getId() +" destination community #"+vm.getHost().getId()/edgeSwitchHostNo+" ("+sortedComm.get(j).getID()+")"+" optimal="+(location==sortedComm.get(j).getID());	
					Log.printLine(forLog);

				}

				return true;
			}
		}
		return false;
	}

	@Override
	public boolean allocateHostForVm(Vm vm) {

		//if (this.vm_table.containsKey(vm.getUid())) {
		//	return true;
		//}
		if (vm.getHost()!=null)
			return true;

		DatacenterBroker tempBroker = null;
		Iterator<SimEntity> entityIterator = CloudSim.getEntityList().iterator();
		// Let's find the broker
		while (entityIterator.hasNext()) {
			SimEntity tempEntity= entityIterator.next();
			//System.out.println("Entity's name: " + tempEntity.getName());
			if (tempEntity.getId() ==  vm.getUserId()) {
				tempBroker = (DatacenterBroker)CloudSim.getEntity(tempEntity.getName());
//				System.out.println("Add VMs of " + tempBroker.getName() + ": " + tempBroker.getVmList().size() + " VM user id:" + Integer.toString(vm.getUserId()));
				ALLvmList = tempBroker.getVmList();
				break;
			}
		}
		
		int location=Integer.MAX_VALUE; 
		//find the location for the VM (based on input file)
		// timestamp = 0
		// broker = Broker_id number
		// vm = not of interest
		
		int service=Integer.parseInt(tempBroker.getName().substring(tempBroker.getName().indexOf('_')+1))+1;
		
		Iterator<ParamsInit> paramsInitListIterator = paramsInitList.iterator();
		while (paramsInitListIterator.hasNext()){
			ParamsInit temp=paramsInitListIterator.next();
			//if (temp.timeStamp==0.0 && temp.cloudservice==service){
			// now we can schedule VM that start later
			if (temp.timeStamp>=0.0 && temp.cloudservice==service){
				location=temp.comm;
				break;
			}
		}
//		System.out.println("service id:" + Integer.toString(service) + " location id: " + Integer.toString(location));
		
		if (location == Integer.MAX_VALUE)
			System.out.println("problem with location id !!!!");
		
		if (this.INIoptimizeAllocation_FogCommunityBased (getHostList(),ALLvmList,method,location)){
			for (Vm v : ALLvmList){
				dc.VmToSwitchid.put(v.getId(), dc.HostToSwitchid.get(v.getHost().getId()));
				dc.VmtoHostlist.put(v.getId(), v.getHost().getId());
			}
			return true;		
		}
		
		return false;
	}

	@Override
	public boolean allocateHostForVm(Vm vm, Host host) 
	{
		int brkr = 0;
		if (host != null && host.vmCreate(vm)) 
		{
			//vm_table.put(vm.getUid(), host);
			brkr = vm.getId();
			Log.formatLine("%.4f:" + "CS #" + brkr + " - VM #" + vm.getId() + " has been allocated to the host#" + host.getId() + 
					" datacenter #" + host.getDatacenter().getId() + "(" + host.getDatacenter().getName() + ") #", 
					CloudSim.clock());
			return true;
		}
		return false;
	}

	@Override
	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) {
		return null;
	}

	@Override
	public void deallocateHostForVm(Vm vm) {
		//Host host = this.vm_table.remove(vm.getUid());

		Host host=vm.getHost();
		if (host != null) {
			host.vmDestroy(vm);
		}
	}

	@Override
	public Host getHost(Vm vm) {
		//return this.vm_table.get(vm.getUid());
		return vm.getHost();
	}

	@Override
	public Host getHost(int vmId, int userId) {
		//return this.vm_table.get(Vm.getUid(userId, vmId));
		Vm vm=this.ALLvmList.get(0);
		for (int i=0; i<this.getHostList().size(); i++)
			if (this.getHostList().get(i).getVm(vmId, userId)!=null)
				return this.getHostList().get(i);
		return vm.getHost();
	}
		
	/**
	 * Adds the ints of a list
	 * 
	 * @param list of ints
	 */	
	protected int sum (List<Integer> list) {
	    int sum = 0;
	    for (int i: list) {
	        sum += i;
	    }
	    return sum;
	}
	/**
	 * Adds the longs of a list
	 * 
	 * @param list of lons
	 */	
	protected Long sumLong (List<Long> list) {
	    long sum = 0;
	    for (Long i: list) {
	        sum += i;
	    }
	    return sum;
	}

public void createCommunitiesSUMO(int numhost, NetworkDatacenter dc){
		
		this.dc=dc;
		// 3 level FatTree
		
		// 9 edge switches, 3 agg switch, 1 root switch
		// 9 communities in first level one per each switch with ids 0-8
		communities=new ArrayList<FogCommunity>();
		// we don't need separate hosts as separate communities
		
		int indexC=0;
		
		FogCommunity c=new FogCommunity(indexC++);
		int edgeSwitchHostNo=(int) (NetworkConstants.EdgeSwitchPort-1);
		for (int i=0; i<dc.getHostList().size(); i++) {
			if (i>0 & Math.floorMod(i,edgeSwitchHostNo)==0){
				communities.add(c);
				c=new FogCommunity(indexC++);
			}
			c.addMember(dc.getHostList().get(i));
		}
		communities.add(c);

		// per agg sw 
		int count=NetworkConstants.Agg_LEVEL;
		int aggSwitchLevelHostNo=(int) ((NetworkConstants.EdgeSwitchPort-1)*(NetworkConstants.AggSwitchPort-1));
		for (int i=0; i < count; i++){
			c=new FogCommunity(indexC++);
			for (int j=0; j < aggSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*aggSwitchLevelHostNo+j));
			communities.add(c);
		}
		
		// fourth per root sw
		int countR=NetworkConstants.ROOT_LEVEL;
		int rootSwitchLevelHostNo=(int) ((NetworkConstants.EdgeSwitchPort-1)*(NetworkConstants.AggSwitchPort-1)*(NetworkConstants.RootSwitchPort));
		for (int i=0; i < countR; i++){
			c=new FogCommunity(indexC++);
			for (int j=0; j < rootSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*rootSwitchLevelHostNo+j));
			communities.add(c);
		}

		// end: all hosts
		 c=new FogCommunity(indexC++);
		for (Host hs : dc.getHostList()) {
			c.addMember(hs);
		}
		communities.add(c);
	}

	public void createCommunities(int numhost, NetworkDatacenter dc){
		
		this.dc=dc;
		// 3 level FatTree
		
		// 8 edge switches, 4 agg switch, 4 root switch
		// 8 communities in first level one per each switch with ids 0-7
		communities=new ArrayList<FogCommunity>();
		// we don't need separate hosts as separate communities
		
		// first each single host separately
//		for (Host hs : dc.getHostList()) {
//			Community c=new Community();
//			c.addMember(hs);
//			communities.add(c);
//		}
		int indexC=0;
		
		// second per edge switch (numhost/numedgeswitches) (edge_switch_ports - 2 members per switch)
		FogCommunity c=new FogCommunity(indexC++);
		int edgeSwitchHostNo=(int) (NetworkConstants.EdgeSwitchPort-2);
		for (int i=0; i<dc.getHostList().size(); i++) {
			if (i>0 & Math.floorMod(i,edgeSwitchHostNo)==0){
				communities.add(c);
				c=new FogCommunity(indexC++);
			}
			c.addMember(dc.getHostList().get(i));
		}
		communities.add(c);
		// third per agg sw 
		int count=NetworkConstants.Agg_LEVEL;
		int aggSwitchLevelHostNo=edgeSwitchHostNo*2;
		for (int i=0; i < count; i++){
			c=new FogCommunity(indexC++);
			for (int j=0; j < aggSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*aggSwitchLevelHostNo+j));
			communities.add(c);
		}
		
		// fourth per root sw
		int countR=NetworkConstants.ROOT_LEVEL;
		int rootSwitchLevelHostNo=aggSwitchLevelHostNo*4;
		for (int i=0; i < countR; i++){
			c=new FogCommunity(indexC++);
			for (int j=0; j < rootSwitchLevelHostNo; j++)
				c.addMember(dc.getHostList().get(i*rootSwitchLevelHostNo+j));
			communities.add(c);
		}

		// end: all hosts
		 c=new FogCommunity(indexC++);
		for (Host hs : dc.getHostList()) {
			c.addMember(hs);
		}
		communities.add(c);
	}

}

class FogAllItems { // for optimizing the summing of parameters for a megahost
	int TotalPes;
	int TotalRam;
	long TotalBw;
	int CapacityPes;
	int CapacityRam;
	long CapacityBw;
	long TotalStorage;
	int TotalMips;
}

class FogCommunity {  // group of hosts only
	private List<Host> hostMembers;
	private int id;
	private int no_members; // number of members
	private Host megaHost;
	private boolean full;
	FogCommunity(int i){
		no_members=0;
		hostMembers=new ArrayList<Host>();
		megaHost=null;
		full=false;
		id=i;
	}
	void setID(int i){
		id=i;
	}
	int getID(){
		return id;
	}
	void addMember(Host nh){
		if (!hostMembers.contains(nh)){
			hostMembers.add(nh);
			no_members+=1;
		}
	}
	boolean isMember(Host nh){
		return hostMembers.contains(nh);
	}
	int getTotalPes(){
		int tot=0;
		for (int i=0; i<no_members; i++)
			tot+=((VmSchedulerSpaceShared)hostMembers.get(i).getVmScheduler()).getFreePes().size();
		return tot;
	}
	int getTotalRam(){
		int tot=0;
		for (int i=0; i<no_members; i++)
			tot+=hostMembers.get(i).getRamProvisioner().getAvailableRam();
		return tot;
	}
	long getTotalBw(){
		long tot=0;
		for (int i=0; i<no_members; i++)
			tot+=hostMembers.get(i).getBwProvisioner().getAvailableBw();
		return tot;
	}
	int getCapacityPes(){
		int tot=0;
		for (int i=0; i<no_members; i++)
			tot+=hostMembers.get(i).getNumberOfPes();
		return tot;
	}
	int getCapacityRam(){
		int tot=0;
		for (int i=0; i<no_members; i++)
			tot+=hostMembers.get(i).getRam();
		return tot;
	}
	long getCapacityBw(){
		long tot=0;
		for (int i=0; i<no_members; i++)
			tot+=hostMembers.get(i).getBw();
		return tot;
	}
	long getTotalStorage(){
		long tot=0;
		for (int i=0; i<no_members; i++)
			tot+=hostMembers.get(i).getStorage();
		return tot;
	}
	int getTotalMips(){
		int tot=0;
		for (int i=0; i<no_members; i++)
			tot+=hostMembers.get(i).getTotalMips();
//			System.out.println(tot);
		return tot;
	}
	List<Host> getMembers(){
		return hostMembers;
	}
	
	FogAllItems getTotalAllItems(){ //count all the elements in a single pass
		FogAllItems all = new FogAllItems();
		all.TotalBw = 0;
		all.TotalMips = 0;
		all.TotalPes = 0;
		all.TotalRam = 0;
		all.TotalStorage = 0;
		for (int i=0; i<no_members; i++) {
			all.TotalPes +=((VmSchedulerSpaceShared)hostMembers.get(i).getVmScheduler()).getFreePes().size();
			all.TotalRam +=hostMembers.get(i).getRamProvisioner().getAvailableRam();
			all.TotalBw +=hostMembers.get(i).getBwProvisioner().getAvailableBw();
			all.TotalStorage +=hostMembers.get(i).getStorage();
			all.TotalMips +=hostMembers.get(i).getTotalMips();
		}
		return all;
	}
	
	FogAllItems getCapacityAllItems(){ //count all the elements in a single pass
		FogAllItems all = new FogAllItems();
		all.CapacityBw = 0;
		all.CapacityPes = 0;
		all.CapacityRam = 0;
		for (int i=0; i<no_members; i++) {
			all.CapacityPes +=hostMembers.get(i).getNumberOfPes();
			all.CapacityRam +=hostMembers.get(i).getRam();
			all.CapacityBw +=hostMembers.get(i).getBw();
		}
		return all;
	}
	
	
	Host getMegaHost(){
		// create new mega host = sum of community members 
		FogAllItems total = getTotalAllItems();
		int ramMB=total.TotalRam;
		long bwh=total.TotalBw;
		long storage=total.TotalStorage;
		int totalMips = total.TotalMips;
		int totalPes = total.TotalPes;
//		int ramMB=getTotalRam();
//		long bwh=getTotalBw();
//		long storage=getTotalStorage();
		List<Pe> peList = new ArrayList<Pe>();
		// changed by AM
//		int totalMips = getTotalMips();
//		for (int j=0; j<getTotalPes();j++)
		for (int j=0; j<totalPes;j++)
				peList.add(new Pe(j, new PeProvisionerSimple(totalMips)));
//				peList.add(new Pe(j, new PeProvisionerSimple(getTotalMips())));
//		System.out.println(" ");	
		megaHost= new Host(
				0,
				new RamProvisionerSimple(ramMB),
				new BwProvisionerSimple(bwh),
				storage,
				peList,
				new VmSchedulerSpaceShared(peList)
			);
		if (ramMB==0) full=true;
		else if (bwh==0) full=true;
		else if (getTotalPes()==0) full=true;
		else full=false;
		return megaHost;
	}
	boolean isMegaHost(Host h){
		return megaHost.equals(h);
	}
	boolean full(){
		return full;
	}
	
}
