/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation
 *               of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009, The University of Melbourne, Australia
 */


package org.cloudbus.cloudsim.examples;

import java.text.DecimalFormat;
import java.util.Random; //Katya

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
//import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.distributions.UniformDistr;
import org.cloudbus.cloudsim.examples.power.Constants;
//import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.power.PowerDatacenter;
import org.cloudbus.cloudsim.power.PowerDatacenterBroker;
import org.cloudbus.cloudsim.power.PowerHostUtilizationHistory;
import org.cloudbus.cloudsim.power.PowerVm;
import org.cloudbus.cloudsim.power.PowerHost;


/**
 * An example showing how to create simulation entities
 * (a DatacenterBroker in this example) in run-time using
 * a globar manager entity (GlobalBroker).
 */
public class CloudSimExample_powerK {

	/** The cloudlet list. */
	private static List<Cloudlet> cloudletList;

	/** The vmList. */
	private static List<Vm> vmList;

	/** Generate 10 random integers in the range 0..99. */
	//public final class RandomInteger {
	
	
	private static int Random_RAM_VMs (int cores){
	    //RAM: 2048, 4096 or 8192 (MB)
		//noCPUs <= noRAMGB
	    Random randomGenerator = new Random();
	    int RAM = 0;
	    
	    int randomInt = randomGenerator.nextInt(3);
	    if (cores == 4) randomInt = randomGenerator.nextInt(2);
	    //Log.printLine("randomInt: " + randomInt);

	    if (randomInt == 0)
	    	  RAM = 8192;
	    else if (randomInt == 1)
	    	  RAM = 4096;
	    else if (randomInt == 2)
	    	  RAM = 2048;
	    //Log.printLine("RAM: " + RAM);
	    return RAM;
	}
	
	private static int Random_cores_VMs (){	    
		//VM cores: 1, 2 or 4 cores		    
		Random randomGenerator = new Random();
		int cores = 0;
		    
		int randomInt = randomGenerator.nextInt(3);
	    cores = (int)Math.pow(2,(double)randomInt);
	    //Log.printLine("RAM: " + RAM);
	    return cores;
	}
	
	
	private static int Unif_Dist_VMs(int max){
	    //number VMs per CloudService: uniformly distributed in [1,10], [1,20] or [1,30]
	   	UniformDistr VM_dist = null;
	   	int VM = 0;
	   
	   //int randomInt = randomGenerator.nextInt(3);
	   	
	   	//Log.printLine("Número generado: " + randomInt);
	   	//VM_dist= new UniformDistr(1,((randomInt)+1)*10);
	   	VM_dist= new UniformDistr(1,max+1);
	   	VM=(int)VM_dist.sample();
	   	Log.printLine("VM number: " + VM);
	   	return VM;
	   	//return 3;
	}
	
	private static List<Vm> createVM(int userId, int vms, int idShift) {
		//Creates a container to store VMs. This list is passed to the broker later
		LinkedList<Vm> list = new LinkedList<Vm>();

		//VM Parameters
		long size = 10000; //image size
		int mips = 250;
		long bw = 1000;
		String vmm = "Xen"; //VMM name
		int coresVM = 0;

		//create VMs
		Vm[] vm = new Vm[vms];
		for(int i = 0; i < vms; i++){
			coresVM = Random_cores_VMs();
			vm[i] = new PowerVm(idShift + i, userId, mips, coresVM, Random_RAM_VMs(coresVM), bw, size, 1,
					vmm, new CloudletSchedulerSpaceShared(),Constants.SCHEDULING_INTERVAL);
			list.add(vm[i]);
		}

		return list;
	}


	private static List<Cloudlet> createCloudlet(int userId, int cloudlets, int idShift){
		// Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();
		//cloudlet parameters
		//long length = 4000000;
		long length = 400000;
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++){
			cloudlet[i] = new Cloudlet(idShift + i, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			// setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			cloudlet[i].setVmId(idShift + i);  //ojo
			list.add(cloudlet[i]);
		}

		return list;
	}


	////////////////////////// STATIC METHODS ///////////////////////

	/**
	 * Creates main() to run this example
	 */
	public static void main(String[] args) {
		//Log.disable(); //.setOutput(_output);
		Log.printLine("Starting CloudSimExample_powerK...");

		try {
			// First step: Initialize the CloudSim package. It should be called
			// before creating any entities.
			// args: [0] num_CloudServices 	(1000, 2000 or 4000))
			//		 [1] number of PMs		(54000 or 108000)
			//		 [2] number of PM cores or Pes (8 or 16)
			//		 [3] GBs of RAM			(16 or 32)
			// 		 [4] Max number of VMs per CS (10, 20 or 30)
			int num_user =  Integer.parseInt(args[0]);  // number of grid users 
			int num_CloudServices = num_user;
			int PMnumber = Integer.parseInt(args[1]); 	// number of PMs
			int PMcores = Integer.parseInt(args[2]); 	// number of cores per PM
			int RAM = Integer.parseInt(args[3]); 		// GBs of RAM
			int max_VMs = Integer.parseInt(args[4]); 	// Max. number of VMs per CS
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = true;  // mean trace events

			int num_VMs = 0;
			int num_Total_VMs = 0;			
			String num_broker= "";

			// Initialize the CloudSim library
			CloudSim.init(num_user, calendar, trace_flag);

			//Katya: This not used in our current implementation - I just leave it for future modifications
			//GlobalBroker globalBroker = new GlobalBroker("GlobalBroker");

			// Second step: Create Datacenters
			//Datacenters are the resource providers in CloudSim. We need at list one of them to run a CloudSim simulation
			@SuppressWarnings("unused")
			PowerDatacenter datacenter0 = createDatacenter("Datacenter_0", PMnumber, PMcores, RAM);

			//Third step: Create Broker
			//Katya: CloudServices represented by brokers 
			DatacenterBroker[] broker = new PowerDatacenterBroker[num_CloudServices];
			
			for(int i=0;i<num_CloudServices;i++){
				num_broker = "Broker_" + i;
				broker[i] = createBroker(num_broker);
				int brokerId = broker[i].getId();
				
				num_VMs = Unif_Dist_VMs(max_VMs);
				//Fourth step: Create VMs and Cloudlets and send them to broker
									
				vmList = createVM(brokerId, num_VMs, 0); //creating VMs for the CLoudService
				cloudletList = createCloudlet(brokerId, num_VMs, 0); 
							
				broker[i].submitVmList(vmList);
				broker[i].submitCloudletList(cloudletList);
				
				num_Total_VMs = num_Total_VMs + num_VMs;
			}
			// Fifth step: Starts the simulation
			CloudSim.startSimulation();

			// Final step: Print results when simulation is over
			List<Cloudlet> newList = null;
			List<Vm> newListVms = null;
			newList = broker[0].getCloudletReceivedList();
			newListVms = broker[0].getVmList();
			
			for(int i=1;i<num_CloudServices;i++){
				newList.addAll(broker[i].getCloudletReceivedList());
				newListVms.addAll(broker[i].getVmList());
			}
			//newList.addAll(globalBroker.getBroker().getCloudletReceivedList());

			CloudSim.stopSimulation();
			
			String msg = "\n" + "number hosts  \t number cores per host \t number RAM per host \t number CS \t max VMs";// \t number used PMs";
			PrintFile_K.AddtoFile("",msg);
			msg =  "\t" + PMnumber + "\t\t" + PMcores+ "\t\t\t" +RAM + "\t\t" + num_CloudServices + "\t\t" + 
					max_VMs + "\n";
			PrintFile_K.AddtoFile("",msg);					
			
			printCloudletList(newList,newListVms,datacenter0);

			Log.printLine("CloudSimExample_K finished!");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
		}
	}

	private static PowerDatacenter createDatacenter(String name, int PM_number, int n_cores, int ram){

		int mips = 1000;
		//int n_cores1 = 8; // Katya
		//int n_cores2 = 16; // Katya
		//int PM_number1 = 5400; //Katya
		//int PM_number2 = 10800; //Katya
		
		// Here are the steps needed to create a PowerDatacenter:
		// 1. We need to create a list to store one or more
		//    Machines
		List<PowerHost> hostList = new ArrayList<PowerHost>();

		// 2. A Machine contains one or more PEs or CPUs/Cores. Therefore, should
		//    create a list to store these PEs before creating
		//    a Machine.
		List<Pe> peList = new ArrayList<Pe>();

		// 3. Create PEs and add these into the list.

		//katya: 8-core machines
		for(int i=0;i<n_cores;i++)
			peList.add(new Pe(i, new PeProvisionerSimple(mips)));
		
	
		//4. Create Hosts with its id and list of PEs and add them to the list of machines
		//int hostId=0;
		//int ram1 = 16384; //host memory (MB) - 16 GB //Katya
		//int ram2 = 32768; //host memory (MB) - 32 GB //Katya
		int ramMB = ((ram==16)  ? 16384 : 32768);
		long storage = 1000000; //host storage (MB)
		int bw = 10000;

		//katya: creating the physical machines 
		for(int i=0;i<PM_number;i++){
			int hostType = 1; //i % Constants.HOST_TYPES;
			hostList.add(
	    			new PowerHostUtilizationHistory(
	    				i,
	    				new RamProvisionerSimple(ramMB),
	    				new BwProvisionerSimple(bw),
	    				storage,
	    				peList,
	    				//new VmSchedulerTimeShared(peList),
	    				//new VmSchedulerTimeSharedOverSubscription(peList),
	    				new VmSchedulerSpaceShared(peList),
	    				Constants.HOST_POWER[hostType])
	    		);
		}
		
		// 5. Create a DatacenterCharacteristics object that stores the
		//    properties of a data center: architecture, OS, list of
		//    Machines, allocation policy: time- or space-shared, time zone
		//    and its price (G$/Pe time unit).
		String arch = "x86";      // system architecture
		String os = "Linux";          // operating system
		String vmm = "Xen";
		double time_zone = 10.0;         // time zone this resource located
		double cost = 3.0;              // the cost of using processing in this resource
		double costPerMem = 0.05;		// the cost of using memory in this resource
		double costPerStorage = 0.1;	// the cost of using storage in this resource
		double costPerBw = 0.001;		// the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>();	//we are not adding SAN devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);


		// 6. Finally, we need to create a PowerDatacenter object.
		PowerDatacenter datacenter = null;
		/*try {
			//datacenter = new Datacenter(name, characteristics, new VmrtionPolicyBinCentric(hostList), storageList, 0);
			//datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
			datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return datacenter;
		 */
		
		try { 
			OptimVmAllocationPolicy_perbroker vm_policy = new OptimVmAllocationPolicy_perbroker(hostList);
			datacenter = new PowerDatacenter(name, characteristics, vm_policy, storageList, 2*Constants.SCHEDULING_INTERVAL);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return datacenter;

	}

	//We strongly encourage users to develop their own broker policies, to submit vms and cloudlets according
	//to the specific rules of the simulated scenario
	private static DatacenterBroker createBroker(String name){

		DatacenterBroker broker = null;
		try {
			broker = new PowerDatacenterBroker(name);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

	/**
	 * Prints the Cloudlet objects
	 * @param list  list of Cloudlets
	 */
	private static void printCloudletList(List<Cloudlet> list, List<Vm> listVm, PowerDatacenter DC_host) {
		int size = list.size();
		Cloudlet cloudlet;
		//katya
		Vm vm = null;
		List<Vm> listVm_brkr =  new ArrayList<Vm>();
		int brokr = 0;
		
		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent +
				"Data center ID" + indent + "VM ID" + indent + indent + "Time" + indent + "Start Time" + indent + "Finish Time");
		PrintFile_K.AddtoFile("","BrokerId - VM ID" + indent + "Cloudlet ID" + indent + indent + "VM RAM" + indent + indent + "VMcores" + 
				indent + indent + "VM MIPS" + indent + indent + "VMsize" + indent + indent + "HOST");
		
		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS){
				Log.print("SUCCESS");

				brokr = cloudlet.getUserId() - 3;
				Iterator<Vm> VmIterator = listVm.iterator();
				while (VmIterator.hasNext()) {
					vm = VmIterator.next();	
					if (vm.getUserId() == brokr + 3)
						listVm_brkr.add(vm);
				}
				if (!listVm_brkr.isEmpty()) { 
					
					vm =  listVm_brkr.get(cloudlet.getVmId());
				
					Log.printLine( indent + indent + cloudlet.getResourceId() + indent + indent + indent + brokr +"-"+ cloudlet.getVmId() +
						indent + indent + indent + dft.format(cloudlet.getActualCPUTime()) +
						indent + indent + dft.format(cloudlet.getExecStartTime())+ indent + indent + indent + dft.format(cloudlet.getFinishTime()));
				
					PrintFile_K.AddtoFile("",indent + brokr + "-" + vm.getId() + " " + // vm.getUserId() +//+ vm.getUid() +
						indent + indent + indent + indent + cloudlet.getCloudletId()+
						indent + indent + indent +  vm.getRam() + indent + indent + indent + vm.getNumberOfPes() + 
						indent + indent + indent + vm.getMips() + indent + indent + indent + vm.getSize());
				}
				listVm_brkr.clear();
			}
		}

	}

	public static class GlobalBroker extends SimEntity {

		private static final int CREATE_BROKER = 0;
		private List<Vm> vmList;
		private List<Cloudlet> cloudletList;
		private DatacenterBroker broker;

		public GlobalBroker(String name) {
			super(name);
		}

		@Override
		public void processEvent(SimEvent ev) {
			switch (ev.getTag()) {
			case CREATE_BROKER:
				setBroker(createBroker(super.getName()+"_"));

				//Create VMs and Cloudlets and send them to broker
				setVmList(createVM(getBroker().getId(), 5, 100)); //creating 5 vms
				setCloudletList(createCloudlet(getBroker().getId(), 10, 100)); // creating 10 cloudlets

				broker.submitVmList(getVmList());
				broker.submitCloudletList(getCloudletList());

				CloudSim.resumeSimulation();

				break;
			/*case VM_CREATE:
				broker.getVmList();
				*/
			default:
				Log.printLine(getName() + ": unknown event type");
				break;
			}
		}

		@Override
		public void startEntity() {
			Log.printLine(super.getName()+" is starting...");
			schedule(getId(), 200, CREATE_BROKER);
		}

		@Override
		public void shutdownEntity() {
		}

		public List<Vm> getVmList() {
			return vmList;
		}

		protected void setVmList(List<Vm> vmList) {
			this.vmList = vmList;
		}

		public List<Cloudlet> getCloudletList() {
			return cloudletList;
		}

		protected void setCloudletList(List<Cloudlet> cloudletList) {
			this.cloudletList = cloudletList;
		}

		public DatacenterBroker getBroker() {
			return broker;
		}

		protected void setBroker(DatacenterBroker broker) {
			this.broker = broker;
		}

	}

}
