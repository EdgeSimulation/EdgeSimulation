package org.cloudbus.cloudsim.examples.network.datacenter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import org.cloudbus.cloudsim.distributions.UniformDistr;

public class generateLoad {
	
	public static void main(String[] args) throws IOException {
		// args: [0] num_CloudServices 	(1000 or 2000)
		//		 [1] Max number of VMs per CS (10, 20 or 30)
		//		 [2] iteration		
		
		
		int CSs = Integer.parseInt(args[0]); 	
		int maxVMs = Integer.parseInt(args[1]); 
		int no = Integer.parseInt(args[2]);
		
		String fileName="load-" + CSs + "-" + maxVMs + "-" + no + ".txt";
		
		loadGeneration(fileName, CSs, maxVMs, no);
	}

	private static void loadGeneration(String fileName, int CS, int maxVMs, int no) throws IOException{
		PrintWriter file = new PrintWriter("./log/load-" + CS + "-" + maxVMs + "-" + no + ".txt");
		
		for (int j=0; j<CS; j++){
			int VMs=Unif_Dist_VMs(maxVMs);
			for (int i=0; i<VMs; i++){
				int cores=Random_cores_VMs();
				int ram=Random_RAM_VMs();
				long length = (int) new UniformDistr(1,6).sample();
				length*=1000000;
				file.println(j + " " + i + " " + cores + " " + ram + " " + length);
			}
		}
		file.close();
	}

	private static int Random_RAM_VMs (){
	    //RAM: 2048, 4096 MB
		//noCPUs <= noRAMGB
	    Random randomGenerator = new Random();
	    int randomInt = randomGenerator.nextInt(2);
	    return 2048*(randomInt+1);
	}
	
	private static int Random_cores_VMs (){	    
		//VM cores: 1, 2 cores		    
		Random randomGenerator = new Random();    
		int randomInt = randomGenerator.nextInt(2);
	    return (int)Math.pow(2,(double)randomInt);
	}
	
	private static int Unif_Dist_VMs(int max){
	    //number VMs per CloudService: uniformly distributed in [1,10], [1,20] or [1,30]
	   	UniformDistr VM_dist = null;
	   	VM_dist= new UniformDistr(1,max+1);
	   	 return (int)VM_dist.sample();
	}
	
}
