package org.cloudbus.cloudsim.examples.network.datacenter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.distributions.UniformDistr;
import org.cloudbus.cloudsim.network.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.network.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.network.datacenter.RootSwitch;
import org.cloudbus.cloudsim.network.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.network.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.network.datacenter.OptimVMAllocationPolicy_CommunityBased_LB_SC;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

public class Test_FatTree_Example {

	/** The cloudlet list. */
	private static List<Cloudlet> cloudletList;

	/** The vmlist. */
	private static List<Vm> vmList;

	private static int Random_RAM_VMs (int cores){
	    //RAM: 2048, 4096 or 8192 (MB)
		//noCPUs <= noRAMGB
	    Random randomGenerator = new Random();
	    int RAM = 0;
	    
	    int randomInt = randomGenerator.nextInt(3);
	    if (cores == 4) randomInt = randomGenerator.nextInt(2);
	    //Log.printLine("randomInt: " + randomInt);

	    if (randomInt == 0)
	    	  RAM = 8192;
	    else if (randomInt == 1)
	    	  RAM = 4096;
	    else if (randomInt == 2)
	    	  RAM = 2048;
	    //Log.printLine("RAM: " + RAM);
	    return RAM;
	}
	
	private static int Random_cores_VMs (){	    
		//VM cores: 1, 2 or 4 cores		    
		Random randomGenerator = new Random();
		int cores = 0;
		    
		int randomInt = randomGenerator.nextInt(3);
	    cores = (int)Math.pow(2,(double)randomInt);
	    //Log.printLine("RAM: " + RAM);
	    return cores;
	}
	
	
	private static int Unif_Dist_VMs(int max){
	    //number VMs per CloudService: uniformly distributed in [1,10], [1,20] or [1,30]
	   	UniformDistr VM_dist = null;
	   	int VM = 0;
	   
	   //int randomInt = randomGenerator.nextInt(3);
	   	
	   	//Log.printLine("Número generado: " + randomInt);
	   	//VM_dist= new UniformDistr(1,((randomInt)+1)*10);
	   	VM_dist= new UniformDistr(1,max+1);
	   	VM=(int)VM_dist.sample();
	   	Log.printLine("VM number: " + VM);
	   	return VM;
	   	//return 3;
	}
	
	private static List<Vm> createVM(int userId, int vms, int idShift) {
		//Creates a container to store VMs. This list is passed to the broker later
		LinkedList<Vm> list = new LinkedList<Vm>();

		//VM Parameters
		long size = 10000; //image size
		int mips = 1000;
		long bw = 1000;
		String vmm = "Xen"; //VMM name
		int coresVM = 0;

		//create VMs
		Vm[] vm = new Vm[vms];
		for(int i = 0; i < vms; i++){
			coresVM = Random_cores_VMs();
			vm[i] = new Vm(idShift + i, userId, mips, coresVM , Random_RAM_VMs(coresVM), bw, size, vmm, new CloudletSchedulerSpaceShared());
			list.add(vm[i]);
		}

		return list;
	}


	private static List<Cloudlet> createCloudlet(int userId, int cloudlets, int idShift){
		// Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();
		//cloudlet parameters
		long length = 4000000;
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++){
			cloudlet[i] = new Cloudlet(idShift + i, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			// setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
		}

		return list;
	}

	
	
	
	/**
	 * Creates main() to run this example.
	 * 
	 * @param args
	 *            the args
	 */
	public static void main(String[] args) {

		Log.disable(); //.setOutput(_output);
		Log.printLine("Starting CloudSimExample_K...");

		try {
			// First step: Initialize the CloudSim package. It should be called
			// before creating any entities.
			// args: [0] num_CloudServices 	(1000, 2000 or 4000))
			//		 [1] number of PMs		(54000 or 108000)
			//		 [2] number of PM cores or Pes (8 or 16)
			//		 [3] GBs of RAM			(16 or 32)
			// 		 [4] Max number of VMs per CS (10, 20 or 30)
			int num_user =  Integer.parseInt(args[0]);  // number of grid users 
			int num_CloudServices = num_user;
			int PMnumber = Integer.parseInt(args[1]); 	// number of PMs
			int PMcores = Integer.parseInt(args[2]); 	// number of cores per PM
			int RAM = Integer.parseInt(args[3]); 		// GBs of RAM
			int max_VMs = Integer.parseInt(args[4]); 	// Max. number of VMs per CS
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = true;  // mean trace events

			int num_VMs = 0;
			int num_Total_VMs = 0;			
			String num_broker= "";

			// Initialize the CloudSim library
			CloudSim.init(num_user, calendar, trace_flag);

			// Second step: Create Datacenters
			// Datacenters are the resource providers in CloudSim. We need at
			// list one of them to run a CloudSim simulation
			@SuppressWarnings("unused")
			NetworkDatacenter datacenter0 = createDatacenter("Datacenter_0", PMnumber, PMcores, RAM);

			// Third step: Create Broker
			DatacenterBroker[] broker = new DatacenterBroker[num_CloudServices];
			
			for(int i=0;i<num_CloudServices;i++){
				num_broker = "Broker_" + i;
				broker[i] = createBroker(num_broker);
				int brokerId = broker[i].getId();
				
				num_VMs = Unif_Dist_VMs(max_VMs);
				//Fourth step: Create VMs and Cloudlets and send them to broker
									
				vmList = createVM(brokerId, num_VMs, 0); //creating VMs for the CLoudService
				cloudletList = createCloudlet(brokerId, num_VMs, 0); 
							
				broker[i].submitVmList(vmList);
				broker[i].submitCloudletList(cloudletList);
				
				num_Total_VMs = num_Total_VMs + num_VMs;
			}


			// Sixth step: Starts the simulation
			CloudSim.startSimulation();
			
			// Final step: Print results when simulation is over
			List<Cloudlet> newList = null;
			List<Vm> newListVms = null;
			newList = broker[0].getCloudletReceivedList();
			newListVms = broker[0].getVmList();
			
			for(int i=1;i<num_CloudServices;i++){
				newList.addAll(broker[i].getCloudletReceivedList());
				newListVms.addAll(broker[i].getVmList());
			}


			CloudSim.stopSimulation();			

			Log.printLine("CloudSimExample_K finished!");

			
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}
	}

	/**
	 * Creates the datacenter.
	 * 
	 * @param name
	 *            the name
	 * 
	 * @return the datacenter
	 */
	private static NetworkDatacenter createDatacenter(String name, int PM_number, int n_cores, int ram) {

		int mips = 1000;

		// Here are the steps needed to create a PowerDatacenter:
		// 1. We need to create a list to store
		// our machine

		List<Host> hostList = new ArrayList<Host>();

		// 2. A Machine contains one or more PEs or CPUs/Cores.
		// In this example, it will have only one core.
		List<Pe> peList = new ArrayList<Pe>();


		// 3. Create PEs and add these into a list.
		for(int i=0;i<n_cores;i++)
			peList.add(new Pe(i, new PeProvisionerSimple(mips)));

		// 4. Create Host with its id and list of PEs and add them to the list
		// of machines
		int ramMB = ((ram==16)  ? 16384 : 32768);
		long storage = 1000000; //host storage (MB)
		int bw = 10000;
		NetworkConstants.BandWidthEdgeHost=bw;

		//katya: creating the physical machines 
		for(int i=0;i<PM_number;i++){
			hostList.add(
	    			new Host(
	    				i,
	    				new RamProvisionerSimple(ramMB),
	    				new BwProvisionerSimple(bw),
	    				storage,
	    				peList,
	    				//new VmSchedulerTimeShared(peList)
	    				new VmSchedulerSpaceShared(peList)
	    			)
	    		);
		}

		// 5. Create a DatacenterCharacteristics object that stores the
		// properties of a data center: architecture, OS, list of
		// Machines, allocation policy: time- or space-shared, time zone
		// and its price (G$/Pe time unit).
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this
		// resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are
		// not
		// adding
		// SAN
		// devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch,
				os,
				vmm,
				hostList,
				time_zone,
				cost,
				costPerMem,
				costPerStorage,
				costPerBw);

		// 6. Finally, we need to create a NetworkDatacenter object.
		NetworkDatacenter datacenter = null;
		try {
			OptimVMAllocationPolicy_CommunityBased_LB_SC cb_policy=new OptimVMAllocationPolicy_CommunityBased_LB_SC(hostList,"LB","LB");
			datacenter = new NetworkDatacenter(
					name,
					characteristics,
					//new NetworkVmAllocationPolicy(hostList),
					cb_policy,
					storageList,
					0);
			
			// Create Internal Datacenter network
			int ports_per_switch = 36;
			CreateNetwork(PM_number, datacenter, ports_per_switch);
			cb_policy.createCommunities(PM_number,datacenter, ports_per_switch);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 * 
	 * @return the datacenter broker
	 */
	private static DatacenterBroker createBroker(String name) {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker(name);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}


	static void CreateNetwork(int numhost, NetworkDatacenter dc, int ports_per_switch) {

		// create 3 level FatTree
		NetworkConstants.EdgeSwitchPort=ports_per_switch;
		NetworkConstants.AggSwitchPort=ports_per_switch;
		NetworkConstants.RootSwitchPort=ports_per_switch;
		
		// number of switches
		NetworkConstants.EDGE_LEVEL=(int) Math.ceil(numhost/(ports_per_switch/2.0));
		NetworkConstants.Agg_LEVEL=NetworkConstants.EDGE_LEVEL;
		NetworkConstants.ROOT_LEVEL=(int) Math.ceil(NetworkConstants.Agg_LEVEL/2.0);

		// core switches
		RootSwitch coreswitch[] = new RootSwitch[NetworkConstants.ROOT_LEVEL];
		for (int i = 0; i < NetworkConstants.ROOT_LEVEL; i++) {
			coreswitch[i] = new RootSwitch("Core" + i, NetworkConstants.ROOT_LEVEL, dc);
			dc.Switchlist.put(coreswitch[i].getId(), coreswitch[i]);
		}

		// aggregation switches
		AggregateSwitch aggswitch[] = new AggregateSwitch[NetworkConstants.Agg_LEVEL];
		int index=0;
		for (int i = 0; i < NetworkConstants.Agg_LEVEL; i++) {
			aggswitch[i] = new AggregateSwitch("Aggregate" + i, NetworkConstants.Agg_LEVEL, dc);
			for (int j=0; j<ports_per_switch/2; j++){
				aggswitch[i].uplinkswitches.add(coreswitch[index]);
				coreswitch[index].downlinkswitches.add(aggswitch[i]);
				if (index==NetworkConstants.ROOT_LEVEL-1){
					index=0;
				}else index++;
			}
			dc.Switchlist.put(aggswitch[i].getId(), aggswitch[i]);
		}
		
		// Edge Switch
		EdgeSwitch edgeswitch[] = new EdgeSwitch[NetworkConstants.EDGE_LEVEL];
		for (int i = 0; i < NetworkConstants.EDGE_LEVEL; i++) {
			edgeswitch[i] = new EdgeSwitch("Edge" + i, NetworkConstants.EDGE_LEVEL, dc);
			for (int j=0; j<NetworkConstants.Agg_LEVEL; j++){
				edgeswitch[i].uplinkswitches.add(aggswitch[j]);
				aggswitch[j].downlinkswitches.add(edgeswitch[i]);
			}
			dc.Switchlist.put(edgeswitch[i].getId(), edgeswitch[i]);
		}

		// attach hosts
		for (Host hs : dc.getHostList()) {
//			hs1.bandwidth = NetworkConstants.BandWidthEdgeHost;
			int switchnum = (int) (hs.getId() / (NetworkConstants.EdgeSwitchPort/2));
//			edgeswitch[switchnum].hostlist.put(hs.getId(),(NetworkHost) hs);
			dc.HostToSwitchid.put(hs.getId(), edgeswitch[switchnum].getId());
//			hs1.sw = edgeswitch[switchnum];
//			List<Host> hslist = hs1.sw.fintimelistHost.get(0D);
//			if (hslist == null) {
//				hslist = new ArrayList<Host>();
//				hs1.sw.fintimelistHost.put(0D, hslist);
//			}
//			hslist.add(hs1);

		}

	}
}