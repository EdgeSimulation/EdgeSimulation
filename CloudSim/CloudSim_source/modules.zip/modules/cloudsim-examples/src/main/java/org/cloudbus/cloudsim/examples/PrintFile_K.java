/**
 * 
 */
package org.cloudbus.cloudsim.examples;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author Anup
 * 
 */
public class PrintFile_K {

	public static String file_name = "";

	public static void AddtoFile(String name, String msg) {
		try {
			if (file_name == "") {
				file_name = "./log/cloudSim_K_Log" + name + ".txt";
			}
			File file = new File(file_name);
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			String text = System.lineSeparator()
					+ msg.replace("\n", System.lineSeparator());
			fw.write(text);
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
