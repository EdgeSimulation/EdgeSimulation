package org.cloudbus.cloudsim.examples.network.datacenter;

//import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
/*import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;*/
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;
//import org.cloudbus.cloudsim.examples.CloudSimExample8;
import org.cloudbus.cloudsim.examples.PrintFile_K;
//import org.cloudbus.cloudsim.examples.CloudSimExample8.GlobalBroker;
import org.cloudbus.cloudsim.examples.power.Constants;
import org.cloudbus.cloudsim.examples.power.Helper;
import org.cloudbus.cloudsim.network.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.network.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.network.datacenter.RootSwitch;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerDatacenter;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerHost;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerHostUtilizationHistory;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicySimple;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmMigrationPolicyFogCommunityBased;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicy;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyMaximumCorrelation;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyMinimumMigrationTime;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyMinimumUtilization;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyRandomSelection;
import org.cloudbus.cloudsim.power.PowerVm;
import org.cloudbus.cloudsim.network.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.network.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.network.datacenter.OptimVMAllocationPolicy_FogCommunityBased_LB_SC;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;



public class Test_FatTree_Example_Power_FogCommunityMigration_SUMO {
	/** The cloudlet list. */
	private static List<Cloudlet> cloudletList;

	/** The vmlist. */
	private static List<Vm> vmList;
	
	private static java.util.Random random;
	
	//Katya: to get the cloudlet start and stop times from SUMO file
	private static List<Double> start_times = new ArrayList<Double>();
	private static List<Double> stop_times = new ArrayList<Double>();
	
	private static Network_PowerDatacenter datacenter;
			
	private static List<Vm> createVM(int userId, int cs, int idShift) {
		//Creates a container to store VMs. This list is passed to the broker later
		List<Vm> list = new ArrayList<Vm>();

		//VM Parameters
		long size = 10000; //image size
		int mips = Constants.HOST_MIPS;
		long bw = 100;
		String vmm = "Xen"; //VMM name
		
		int cores=random.nextBoolean() ? 1 : 2;
		int ram=random.nextBoolean() ? 1 : 2;

		int i=0;
		//create VMs
		list.add(new PowerVm(idShift + i, userId, mips, cores, ram, bw, size, 1, 
					vmm, new CloudletSchedulerSpaceShared(), Constants.SCHEDULING_INTERVAL));		
		return list;
	}


	private static List<Cloudlet> createCloudlet(int userId, int cs, int idShift){
		// Creates a container to store Cloudlets
		List<Cloudlet> list = new ArrayList<Cloudlet>();
		//cloudlet parameters
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();
		
		int length=3500000;

		int i=0;
		list.add(new Cloudlet(idShift + i, length, pesNumber, fileSize, outputSize, 
				utilizationModel, utilizationModel, utilizationModel));
		// setting the cancellation time for (SUMO) cloudlets
		list.get(i).setFinishTime(stop_times.get(idShift + i)-start_times.get(idShift + i));
		// setting the owner of these Cloudlets
		list.get(i).setUserId(userId);

		return list;
	}

	
	
	/**
	 * Creates main() to run this example.
	 * 
	 * @param args
	 *            the args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {

		//Log.disable(); //.setOutput(_output);
		//Log.setOutput(_output);
		
		random = new Random();
				
		java.util.Date d = new java.util.Date();
		String arguments="";
		for (int i=0; i< args.length; i++)
			arguments=arguments+"_"+args[i];
		//File file = new File("./log/fogCloudSim_K_Log_" + arguments + ".txt");
		File file = new File("./log/fogSUMOCloudSim_Log_" + arguments + ".txt");
		file.createNewFile();
		Log.setOutput(new FileOutputStream(file));
		Log.printLine("Starting fogCloudSimExample_K...");
		
		PrintFile_K.AddtoFile(arguments,"");					


		try {
			// First step: Initialize the CloudSim package. It should be called
			// before creating any entities.
			// args: [0] number of PMs		(80)
			//		 [1] type of PMs		(1 or 2)
			//		 [2] VM allocation policy (lb, sc, dvfs)
			//		 [3] VM migration policy (lb-mad, sc-mad, dvfs) (if dvfs then no migrations)
			//		 [4] num of FS (VMs) (150, 200, 300)
			//		 [5] placement communities file
			//		 [6] migration communities file
			
			
			
			int PMnumber = Integer.parseInt(args[0]); 	// number of PMs
			int hostType = Integer.parseInt(args[1]); 	// type of host (defines cpus, ram, mips, bw, storage)
						
			String allocate = args[2];  // allocation policy
			String migrate = args[3];   // migration policy
			String select = "";		// selection policy
			
			String placFileName = args[5];  // initial placement input file (time stamp ; fog service - vm id ; community id)
			String migFileName = args[6];   // migrations with destination community based on a mobility mode input file (time stamp ; fog service - vm id ; community id)
			
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = true;  // mean trace events

			int num_Total_VMs = Integer.parseInt(args[4]); 	// number of VMs;			
			String num_broker= "";

			int num_CloudServices=Integer.parseInt(args[4]); 	// number of fog services (tenants)
			int num_brokers = 0; 							// number of DatacenterBrokers finally run
			// Initialize the CloudSim library
			CloudSim.init(num_CloudServices, calendar, trace_flag);

			// Second step: Create Datacenters
			// Datacenters are the resource providers in CloudSim. We need at
			// list one of them to run a CloudSim simulation
			//@SuppressWarnings("unused")
			createDatacenter("Datacenter_0", PMnumber, hostType, allocate, migrate, select, placFileName, migFileName);
			datacenter.setDisableMigrations(false);

			// Third step: Create Broker
			DatacenterBroker[] broker = new DatacenterBroker[0];//[num_CloudServices];
			
			int i=0;
/*			for (double start : start_times) {
				if (start == 0.0)
				{
					num_broker = "Broker_" + i;
					broker[i] = createBroker(num_broker);
					int brokerId = broker[i].getId();

					//Fourth step: Create VMs and Cloudlets and send them to broker
						
					vmList = createVM(brokerId, i, 0); //creating VMs for the CLoudService
					cloudletList = createCloudlet(brokerId, i, 0);
									
					broker[i].submitVmList(vmList);
					broker[i].submitCloudletList(cloudletList);
						
					num_Total_VMs = num_Total_VMs + vmList.size();					
					i++;
				}
				else break;
			}		
			
			num_brokers=i;*/
			num_brokers=0;
			
			GlobalBroker[] globalBroker = new GlobalBroker[num_CloudServices-num_brokers];
			
			while (i < (num_CloudServices-num_brokers)) {
				num_broker = "Broker_" + i;
				globalBroker[i] = new GlobalBroker(num_broker);
				i++;
			}
			
			// Sixth step: Starts the simulation
			double lastClock = CloudSim.startSimulation();
			
			// Final step: Print results when simulation is over
			List<Vm> newList = null;
			if (num_brokers > 0) {
				newList = broker[0].getVmList();
				for(int c=1;c<num_CloudServices;i++)
				{
					newList.addAll(broker[c].getVmList());
				}
			}
			else {
				newList = globalBroker[0].getBroker().getVmList();
			}
			for(int c=1;c<num_CloudServices;c++)
			{
				newList.addAll(globalBroker[c].getBroker().getVmList());
			}
			
			CloudSim.stopSimulation();

			String msg = "\n" + "number hosts  \t number cores per host \t number RAM per host \t number CS";// \t number used PMs";
			PrintFile_K.AddtoFile(arguments,msg);
			msg =  "\t" + PMnumber + "\t\t" + Constants.HOST_PES[hostType]+ "\t\t\t" +Constants.HOST_RAM[hostType] + "\t\t" + num_CloudServices + "\n";
			PrintFile_K.AddtoFile(arguments,msg);					
			

			Helper.printResults_1(
					datacenter,
					newList,
					lastClock,
					"PowerNet",
					Constants.OUTPUT_CSV,
					"./log/");

			Log.printLine("CloudSimExample_K finished!");

			
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}
	}

	/**
	 * Creates the datacenter.
	 * 
	 * @param name
	 *            the name
	 * 
	 * @return the datacenter
	 */
	private static void createDatacenter(String name, int PM_number, int hostType, String allocate, String migrate, String select, String placFileName, String migFileName) {

		
		int mips = Constants.HOST_MIPS;

		// Here are the steps needed to create a PowerDatacenter:
		// 1. We need to create a list to store
		// our machine

		List<Network_PowerHost> hostList = new ArrayList<Network_PowerHost>();

		// 2. A Machine contains one or more PEs or CPUs/Cores.
		// In this example, it will have only one core.
		List<Pe> peList = new ArrayList<Pe>();


		// 3. Create PEs and add these into a list.
		for(int i=0;i<Constants.HOST_PES[hostType];i++)
			peList.add(new Pe(i, new PeProvisionerSimple(mips)));

		// 4. Create Host with its id and list of PEs and add them to the list
		// of machines
		
		NetworkConstants.BandWidthEdgeHost=Constants.HOST_BW;

		//katya: creating the physical machines 
		for(int i=0;i<PM_number;i++){
			
			hostList.add(
	    			new Network_PowerHostUtilizationHistory(
	    				i,
	    				new RamProvisionerSimple(Constants.HOST_RAM[hostType]),
	    				new BwProvisionerSimple(Constants.HOST_BW),
	    				Constants.HOST_STORAGE,
	    				peList,
	    				//new VmSchedulerTimeShared(peList),
	    				new VmSchedulerSpaceShared(peList),
	    				Constants.HOST_POWER[hostType]
	    			)
	    		);
		}

		// 5. Create a DatacenterCharacteristics object that stores the
		// properties of a data center: architecture, OS, list of
		// Machines, allocation policy: time- or space-shared, time zone
		// and its price (G$/Pe time unit).
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this
		// resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are
		// not
		// adding
		// SAN
		// devices by now
		
		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch,
				os,
				vmm,
				hostList,
				time_zone,
				cost,
				costPerMem,
				costPerStorage,
				costPerBw);

		// 6. Finally, we need to create a NetworkDatacenter object.
		datacenter = null;
		try {
			VmAllocationPolicy cb_policy=getVmAllocationPolicy(allocate, hostList, placFileName);
			VmAllocationPolicy mg_policy=getVmMigrationPolicy(migrate,select,"1",hostList, migFileName); 
			datacenter = new Network_PowerDatacenter(
					name,
					characteristics,
					//new NetworkVmAllocationPolicy(hostList),
					cb_policy,
					mg_policy,
					storageList,
					Constants.SCHEDULING_INTERVAL);
			
			// Create Internal Datacenter network
			CreateNetwork(PM_number, datacenter);
			if (cb_policy.getClass().getName().equals("org.cloudbus.cloudsim.network.datacenter.OptimVMAllocationPolicy_FogCommunityBased_LB_SC"))
				((OptimVMAllocationPolicy_FogCommunityBased_LB_SC) cb_policy).createCommunitiesSUMO(PM_number,datacenter);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static VmAllocationPolicy getVmAllocationPolicy(
			String vmAllocationPolicyName,
			List<Network_PowerHost> hostList,
			String placFileName) {
		VmAllocationPolicy vmAllocationPolicy = null;
		String method="";
		
		if (vmAllocationPolicyName.equals("lb")) {
			method="LB";
			vmAllocationPolicy = new OptimVMAllocationPolicy_FogCommunityBased_LB_SC(hostList, method, placFileName); 
		} else if (vmAllocationPolicyName.equals("sc")) {
			method="SC";
			vmAllocationPolicy = new OptimVMAllocationPolicy_FogCommunityBased_LB_SC(hostList, method, placFileName);
		} else  //(vmAllocationPolicyName.equals("dvfs")) {
			vmAllocationPolicy = new Network_PowerVmAllocationPolicySimple(hostList);
		
		if (vmAllocationPolicy.getClass().getName().equals("org.cloudbus.cloudsim.network.datacenter.OptimVMAllocationPolicy_FogCommunityBased_LB_SC"))
			{
			start_times = ((OptimVMAllocationPolicy_FogCommunityBased_LB_SC) vmAllocationPolicy).start_times_SUMO;
			stop_times = ((OptimVMAllocationPolicy_FogCommunityBased_LB_SC) vmAllocationPolicy).stop_times_SUMO;
			}
		
		return vmAllocationPolicy;
	}

	
	
	
	public static VmAllocationPolicy getVmMigrationPolicy(
			String vmAllocationPolicyName,
			String vmSelectionPolicyName,
			String parameterName,
			List<Network_PowerHost> hostList,
			String migFileName) {
		VmAllocationPolicy vmAllocationPolicy = null;
		Network_PowerVmSelectionPolicy vmSelectionPolicy = null;
		if (!vmSelectionPolicyName.isEmpty()) {
			vmSelectionPolicy = getVmSelectionPolicy(vmSelectionPolicyName);
		}
		if (vmAllocationPolicyName.equals("dvfs")) { // no migrations
			vmAllocationPolicy = new Network_PowerVmAllocationPolicySimple(hostList);
		} else if (vmAllocationPolicyName.startsWith("lb")) {
			String originalPolicy=vmAllocationPolicyName.substring(vmAllocationPolicyName.indexOf("-")+1);
			vmAllocationPolicy = new Network_PowerVmMigrationPolicyFogCommunityBased(hostList,vmSelectionPolicy,originalPolicy, parameterName,"lb", migFileName);
		}
		else if (vmAllocationPolicyName.startsWith("sc")) {
			String originalPolicy=vmAllocationPolicyName.substring(vmAllocationPolicyName.indexOf("-")+1);
			vmAllocationPolicy = new Network_PowerVmMigrationPolicyFogCommunityBased(hostList,vmSelectionPolicy,originalPolicy, parameterName,"sc", migFileName);
		}
		else {
			System.out.println("Unknown VM migration policy: " + vmAllocationPolicyName);
			System.exit(0);
		}
		return vmAllocationPolicy;
	}

	
	/**
	 * Gets the vm selection policy.
	 * 
	 * @param vmSelectionPolicyName the vm selection policy name
	 * @return the vm selection policy
	 */
	public static Network_PowerVmSelectionPolicy getVmSelectionPolicy(String vmSelectionPolicyName) {
		Network_PowerVmSelectionPolicy vmSelectionPolicy = null;
		if (vmSelectionPolicyName.equals("mc")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyMaximumCorrelation(
					new Network_PowerVmSelectionPolicyMinimumMigrationTime());
		} else if (vmSelectionPolicyName.equals("mmt")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyMinimumMigrationTime();
		} else if (vmSelectionPolicyName.equals("mu")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyMinimumUtilization();
		} else if (vmSelectionPolicyName.equals("rs")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyRandomSelection();
		} else {
			System.out.println("Unknown VM selection policy: " + vmSelectionPolicyName);
			System.exit(0);
		}
		return vmSelectionPolicy;
	}

	
	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 * 
	 * @return the datacenter broker
	 */
	private static DatacenterBroker createBroker(String name) {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker(name);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}
	
	/**
	 * Creates the Globalbroker.
	 * 
	 * @return the GlobalBroker broker
	 */
	private static GlobalBroker	createGlobalBroker(String name) {
		GlobalBroker broker = null;
		try {
			broker = new GlobalBroker(name);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

// specific example with 1Gb access links on ES to host, and 10Gb aggregation and core links between switches
	static void CreateNetwork(int numhost, NetworkDatacenter dc) {

		// number of switches
		NetworkConstants.EDGE_LEVEL=9;
		NetworkConstants.Agg_LEVEL=3;
		NetworkConstants.ROOT_LEVEL=1;
		
		// 
		NetworkConstants.EdgeSwitchPort=numhost/NetworkConstants.EDGE_LEVEL+1;  // 5 1Gb hosts + 1 10 Gb to AS
		NetworkConstants.AggSwitchPort=4;	
		NetworkConstants.RootSwitchPort=3;
		

		// bandwidth is set in NetworkConstants (1 gb and 10 gb)

		// core switches
		RootSwitch coreswitch[] = new RootSwitch[NetworkConstants.ROOT_LEVEL];
		for (int i = 0; i < NetworkConstants.ROOT_LEVEL; i++) {
			coreswitch[i] = new RootSwitch("Core" + i, NetworkConstants.ROOT_LEVEL, dc);
			dc.Switchlist.put(coreswitch[i].getId(), coreswitch[i]);
		}

		// aggregation switches
		AggregateSwitch aggswitch[] = new AggregateSwitch[NetworkConstants.Agg_LEVEL];
		for (int i = 0; i < NetworkConstants.Agg_LEVEL; i++) {
			aggswitch[i] = new AggregateSwitch("Aggregate" + i, NetworkConstants.Agg_LEVEL, dc);
				aggswitch[i].uplinkswitches.add(coreswitch[0]);
				coreswitch[0].downlinkswitches.add(aggswitch[i]);
			dc.Switchlist.put(aggswitch[i].getId(), aggswitch[i]);
		}
		
		// Edge Switch
		EdgeSwitch edgeswitch[] = new EdgeSwitch[NetworkConstants.EDGE_LEVEL];
		for (int i = 0; i < NetworkConstants.EDGE_LEVEL; i++) {
			edgeswitch[i] = new EdgeSwitch("Edge" + i, NetworkConstants.EDGE_LEVEL, dc);
			edgeswitch[i].uplinkswitches.add(aggswitch[i/3]);
			aggswitch[i/3].downlinkswitches.add(edgeswitch[i]);
			dc.Switchlist.put(edgeswitch[i].getId(), edgeswitch[i]);
		}

		// attach hosts
		int hostPerSwitch = numhost / NetworkConstants.EDGE_LEVEL;
		int switchnum = 0;
		int hostsOnSwitch=0;
		for (Host hs : dc.getHostList()) {
			dc.HostToSwitchid.put(hs.getId(), edgeswitch[switchnum].getId());
			hostsOnSwitch++;
			if (hostsOnSwitch == hostPerSwitch){
				switchnum++;
				hostsOnSwitch=0;
			}
		}
	}
	
	public static class GlobalBroker extends SimEntity {

		private static final int CREATE_BROKER = 0;
		private List<Vm> vmList;
		private List<Cloudlet> cloudletList;
		private DatacenterBroker broker;

		public GlobalBroker(String name) {
			super(name);
		}

		@Override
		public void processEvent(SimEvent ev) {
			switch (ev.getTag()) {
			case CREATE_BROKER:
				setBroker(createBroker(super.getName()));
							
				// 1 cloudlet per broker. 
				int num_cloudlet = Integer.parseInt(super.getName().substring(super.getName().indexOf('_')+1,super.getName().length())); 
				//Create VMs and Cloudlets and send them to broker
				setVmList(createVM(getBroker().getId(), 1, num_cloudlet)); 
				setCloudletList(createCloudlet(getBroker().getId(), 1, num_cloudlet)); 

				broker.submitVmList(getVmList());
				broker.submitCloudletList(getCloudletList());

				CloudSim.resumeSimulation();

				break;

			default:
				Log.printLine(getName() + ": unknown event type");
				break;
			}
		}
		
		@Override
		public void startEntity() {
			Log.printLine(super.getName()+" is starting...");
			int cual = Integer.parseInt(super.getName().substring(super.getName().indexOf('_')+1,super.getName().length()));
			schedule(getId(), start_times.get(cual), CREATE_BROKER);
			//schedule(getId(), 3, CREATE_BROKER);
		}

		@Override
		public void shutdownEntity() {
		}

		public List<Vm> getVmList() {
			return vmList;
		}

		protected void setVmList(List<Vm> vmList) {
			this.vmList = vmList;
		}

		public List<Cloudlet> getCloudletList() {
			return cloudletList;
		}

		protected void setCloudletList(List<Cloudlet> cloudletList) {
			this.cloudletList = cloudletList;
		}

		public DatacenterBroker getBroker() {
			return broker;
		}

		protected void setBroker(DatacenterBroker broker) {
			this.broker = broker;
		}

	}

}