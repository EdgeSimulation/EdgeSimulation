package org.cloudbus.cloudsim.examples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//Katya
import java.util.Iterator;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
//import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.core.CloudSim;
//Katya: para acceder a la lista de VMs
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.core.SimEntity;

/* Algorithm binCentric: 
 * (from gabay13variable)
 * items = VMs bins=hosts
 * 
 * binCentric fit items into bins according to bin centric heuristics
 * 
 * Algorithm 2: BFD Bin Centric
 * 
 * While The list of bins is not empty do
 *    Compute sizes
 *    Select b the smallest bin 
 *    While An unpacked item fits into b do
 *       Compute sizes 
 *       Pack the biggest feasible item into b
 *    end while
 *    Remove b from the list of bins
 * end while
 * if An item has not been packed then
 *    return Failure
 * return Success */

/**
 * Optimisation based {@link Vm} allocation policy.
 * 
 * (copiado de la clase RoundRobinVmAllocationPolicy.java)
 * 
 * @author Katja Gilly
 */
public class OptimVmAllocationPolicy_perbroker extends org.cloudbus.cloudsim.VmAllocationPolicy {
	
	private static final boolean FALSE = false;

	/** Katya: Indicates if it is the first call to the allocation policy **/
	private int ini=0;

	/** The vm table. */
	private Map<String, Host> vmTable;

	/** Katya: The requested vm list. */
	private List<Vm> ALLvmList = null;

	/** The used pes. */
	private Map<String, Integer> usedPes;

	/** The free pes. */
	private List<Integer> freePes;

	/** Katya: Free RAM. */
	private List<Integer> freeRam;

	/** Katya: Free storage. */
	private List<Long> freeStorage;
	
	/** Katya: Used BW. */
	private Map<String, Long> usedBw;
	
	/** Katya: Free BW. */
	private List<Long> freeBw;
	
	private final Map<String, Host> vm_table = new HashMap<String, Host>();
	
	public OptimVmAllocationPolicy_perbroker(List<? extends Host> list) {
		super(list);
		setFreePes(new ArrayList<Integer>());
		setFreeRAM(new ArrayList<Integer>());		//Katya
		setFreeStorage(new ArrayList<Long>()); 		//Katya
		setFreeBW(new ArrayList<Long>());			//Katya
		for (Host host : getHostList()) {
			getFreePes().add(host.getNumberOfPes());
			getFreeRam().add(host.getRam());
			getFreeStorage().add(host.getStorage());
			getFreeBw().add(host.getBw());
		}

		setVmTable(new HashMap<String, Host>());
		setUsedPes(new HashMap<String, Integer>());
	}
	
	protected List<Long> ComputeSize (int which, List<Host> HostList, List<Vm> Vmlist) {
		
		long VmRequestedBw = 0;
		double alpha_Bw = 0;
		int VmRequestedRam = 0;
		double alpha_Ram = 0;
		int VmNumberOfPes = 0;
		double alpha_Pes = 0;
		double VmRequestedMips = 0;
		//double alpha_Mips = 0;
		long VmRequestedSize = 0;
		double alpha_Size = 0;
		List<Long> hostSizes = new ArrayList<Long>();
		List<Long> VmSizes = new ArrayList<Long>();
		int i = 0;
		
		List<Long> freeBwTmp = new ArrayList<Long>();
		for (Long freeBw : getFreeBw()) {
			freeBwTmp.add(freeBw);
		}	
		List<Integer> freeRamTmp = new ArrayList<Integer>();
		for (Integer freeRam : getFreeRam()) {
			freeRamTmp.add(freeRam);
		}	
		List<Integer> freePesTmp = new ArrayList<Integer>();
		for (Integer freePes : getFreePes()) {
			freePesTmp.add(freePes);
		}
		List<Long> freeStorageTmp = new ArrayList<Long>();
		for (Long freeStorage : getFreeStorage()) {
			freeStorageTmp.add(freeStorage);
		}	
		
		Iterator<Vm> VmIterator = Vmlist.iterator();
		while (VmIterator.hasNext()) {
			Vm temp_Vm = VmIterator.next();	
			VmRequestedBw = VmRequestedBw + temp_Vm.getCurrentRequestedBw();			//BW	
			VmRequestedRam = VmRequestedRam + temp_Vm.getCurrentRequestedRam();			//RAM	
			VmNumberOfPes = VmNumberOfPes + temp_Vm.getNumberOfPes();					//Number of pes
			VmRequestedMips = VmRequestedMips +  temp_Vm.getCurrentRequestedMaxMips();	//MIPS
			VmRequestedSize = VmRequestedSize +  temp_Vm.getSize();						//size
		}

		// ALPHA COMPUTATION
		alpha_Bw = (double) VmRequestedBw / this.sumLong(freeBw);
		alpha_Ram = (double) VmRequestedRam / this.sum(freeRam);
		alpha_Pes = (double) VmNumberOfPes / this.sum(freePes);
//		alpha_Mips = (double)  this.sum(freeMips) / VmRequestedMips
		alpha_Size = (double) VmRequestedSize / this.sumLong(freeStorage);

		//PrintFile_K.AddtoFile("alpha_Bw =" + alpha_Bw + " alpha_Ram =" +alpha_Ram + " alpha_Pes =" + alpha_Pes + " alpha_Size =" + alpha_Size);
//		System.out.println("alpha_Bw =" + alpha_Bw + "\t alpha_Ram =" +alpha_Ram + "\t alpha_Pes =" + alpha_Pes + "\t alpha_Size =" + alpha_Size);
		
		i = 0;
		
		if (which == 0)	{			// ComputeSize for HOSTS
			Host esteHost = null;
			while (i < HostList.size()) {
				esteHost = HostList.get(i);
				hostSizes.add((long) (alpha_Bw * esteHost.getBw()  + 
						alpha_Ram * esteHost.getRam() + 
						alpha_Pes * esteHost.getNumberOfFreePes() + 
						alpha_Size * esteHost.getStorage()));	
				i++;
			}
			return hostSizes;
		}
		else if  (which == 1) {		// ComputeSize for VMs
			Vm estaVm = null;
			while (i < Vmlist.size()) {
				estaVm = Vmlist.get(i);
				VmSizes.add((long) (alpha_Bw * estaVm.getCurrentRequestedBw() + 
						alpha_Ram * estaVm.getCurrentRequestedRam() + 
						alpha_Pes * estaVm.getNumberOfPes() + 
						alpha_Size * estaVm.getSize()));	
				i++;
			}
			return VmSizes;
		}
		return null;
	}
	
	
	public List<Map<String, Host>> INIoptimizeAllocation_bincentric (List<Host> HostList, List<Vm> Vmlist) {
		

		List<Long> VmSizes = null;
		List<Long> hostSizes = null;
		boolean allocated = FALSE;
		List<Host> newHostlist = new ArrayList<Host>(HostList);		
		Host smallestHost = null;
		Vm smallestVm = null;
		Vm largestVm = null;
		int brkr = 0;	
		Long smallestHost_size = (long) 0;
		Long smallestVm_size = (long) 0;
		
			
		PrintFile_K.AddtoFile("","Timestamp" +"\t\t"+ "Host ID" +"\t\t" + "no. of VMs" + "\t\t" + "VM list (CS no. - VM no.)" + "\t\t" +
				"VM RAM" +  "\t\t" + "VMcores" + "\t\t" + "VM MIPS" + "\t\t" + "VMsize");
		while (newHostlist.size() > 0) 												// While the list of bins is not empty
		{
			List<Vm> newVmlist = new ArrayList<Vm>();								// Exclude already allocated Vms from the list
			for (Vm temp : Vmlist) {
				if (temp.getHost() == null)
					newVmlist.add(temp);
			}
			/*if (newVmlist.size() < 10) {
				PrintFile_K.AddtoFile("CUIDADO");	
			}*/
			if (newVmlist.size()==0) break;
			
			hostSizes = ComputeSize (0, newHostlist, newVmlist);					// Compute sizes hosts
			
			//smallestHost = HostList.get(HostList.indexOf(newHostlist.get(hostSizes.indexOf(Collections.min(hostSizes)))));
			smallestHost = newHostlist.get(hostSizes.indexOf(Collections.min(hostSizes)));
			smallestHost_size = Collections.min(hostSizes);
		
			VmSizes = ComputeSize (1, newHostlist, newVmlist);						// Compute sizes Vms
			smallestVm = newVmlist.get(VmSizes.indexOf(Collections.min(VmSizes))); 
			smallestVm_size = Collections.min(VmSizes);
			
			while (Collections.min(VmSizes) < smallestHost_size) {					// While an unpacked item fits into b do
				largestVm = newVmlist.get(VmSizes.indexOf(Collections.max(VmSizes)));
				allocated = 														// Pack the biggest feasible item into bin
						allocateHostForVm(largestVm, smallestHost);
				if (allocated) {
					//update used resources of host
					getVmTable().put(largestVm.getUid(), 
							newVmlist.get(VmSizes.indexOf(Collections.max(VmSizes))).getHost());
					getUsedPes().put(largestVm.getUid(),
							largestVm.getNumberOfPes());
					int who = HostList.indexOf(smallestHost);
					getFreePes().set(who, getFreePes().get(smallestHost.getId()) - largestVm.getNumberOfPes());
					getFreeRam().set(who, getFreeRam().get(smallestHost.getId()) - largestVm.getCurrentAllocatedRam());
					getFreeStorage().set(who, getFreeStorage().get(smallestHost.getId()) - largestVm.getCurrentAllocatedSize());
					getFreeBw().set(who, getFreeBw().get(smallestHost.getId()) - largestVm.getCurrentAllocatedBw());

					smallestHost_size = smallestHost_size - Collections.max(VmSizes);
					brkr = largestVm.getUserId()-3;
					PrintFile_K.AddtoFile("",CloudSim.clock() + ":\t\t\t" + 
							smallestHost.getId() + "\t\t\t" +  
							HostList.get(HostList.indexOf(smallestHost)).getVmList().size() +
							"\t\t\t" +  brkr + "-" + largestVm.getId() + 
							"\t\t\t" + largestVm.getRam() +
							"\t\t\t" + largestVm.getNumberOfPes() + 
							"\t\t\t" + largestVm.getMips() + 
							"\t\t\t" + largestVm.getSize());
				}
				//newVmlist.remove(VmSizes.indexOf(Collections.max(VmSizes)));
				newVmlist.remove(largestVm);
				if (!newVmlist.isEmpty()) VmSizes = ComputeSize (1, newHostlist, newVmlist);

				if (newVmlist.size() == 0) 
					break;
				}
			//newHostlist.remove(hostSizes.indexOf(Collections.min(hostSizes)));
			newHostlist.remove(smallestHost);
			//hostSizes = ComputeSize (0, newHostlist, Vmlist);						// Compute sizes (bins)
		}
		
		return null;
	}

	@Override
	public boolean allocateHostForVm(Vm vm) {
		if (this.vm_table.containsKey(vm.getUid())) {
			return true;
		}

		boolean vm_allocated = false;
		DatacenterBroker tempBroker = null;
		//Katya
		//Host host = getHostList().get(0);
		Iterator<SimEntity> entityIterator = CloudSim.getEntityList().iterator();
		// Let's find the broker
		while (entityIterator.hasNext()) {
			SimEntity tempEntity= entityIterator.next();
			//System.out.println("Entity's name: " + tempEntity.getName());
			if (tempEntity.getId() ==  vm.getUserId()) {
				tempBroker = (DatacenterBroker)CloudSim.getEntity(tempEntity.getName());
				//System.out.println("Add VMs of " + tempBroker.getName() + ": " + tempBroker.getVmList().size());
				ALLvmList = tempBroker.getVmList();
				break;
			}
		}
		
		this.INIoptimizeAllocation_bincentric (getHostList(),ALLvmList);
			
		if (vm.getHost()!=null) {
			vm_allocated = true;
		}			
		
		return vm_allocated;
	}

	@Override
	public boolean allocateHostForVm(Vm vm, Host host) 
	{
		int brkr = 0;
		if (host != null && host.vmCreate(vm)) 
		{
			vm_table.put(vm.getUid(), host);
			brkr = vm.getId();
			Log.formatLine("%.4f:" + "CS #" + brkr + " - VM #" + vm.getId() + " has been allocated to the host#" + host.getId() + 
					" datacenter #" + host.getDatacenter().getId() + "(" + host.getDatacenter().getName() + ") #", 
					CloudSim.clock());
			return true;
		}
		return false;
	}

	@Override
	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) {
		return null;
	}

	@Override
	public void deallocateHostForVm(Vm vm) {
		Host host = this.vm_table.remove(vm.getUid());

		if (host != null) {
			host.vmDestroy(vm);
		}
	}

	@Override
	public Host getHost(Vm vm) {
		return this.vm_table.get(vm.getUid());
	}

	@Override
	public Host getHost(int vmId, int userId) {
		return this.vm_table.get(Vm.getUid(userId, vmId));
	}
	
	/**
	 * Gets the vm table.
	 * 
	 * @return the vm table
	 */
	public Map<String, Host> getVmTable() {
		return vmTable;
	}

	/**
	 * Sets the vm table.
	 * 
	 * @param vmTable the vm table
	 */
	protected void setVmTable(Map<String, Host> vmTable) {
		this.vmTable = vmTable;
	}

	/**
	 * Gets the used pes.
	 * 
	 * @return the used pes
	 */
	protected Map<String, Integer> getUsedPes() {
		return usedPes;
	}

	/**
	 * Sets the used pes.
	 * 
	 * @param usedPes the used pes
	 */
	protected void setUsedPes(Map<String, Integer> usedPes) {
		this.usedPes = usedPes;
	}

	/**
	 * Gets the free pes.
	 * 
	 * @return the free pes
	 */
	protected List<Integer> getFreePes() {
		return freePes;
	}

	/**
	 * Sets the free pes.
	 * 
	 * @param freePes the new free pes
	 */
	protected void setFreePes(List<Integer> freePes) {
		this.freePes = freePes;
	}
	
	/**
	 * Katya: Gets free RAM.
	 * 
	 * @return free RAM
	 */
	protected List<Integer> getFreeRam() {
		return freeRam;
	}

	/**
	 * Sets  free RAM.
	 * 
	 * @param freeRAM the new free RAM
	 */
	protected void setFreeRAM(List<Integer> freeRam) {
		this.freeRam = freeRam;
	}
	
	/**
	 * Katya: Gets free Storage.
	 * 
	 * @return free Storage
	 */
	protected List<Long> getFreeStorage() {
		return freeStorage;
	}

	/**
	 * Sets  free Storage.
	 * 
	 * @param freeStorage the new free Storage
	 */
	protected void setFreeStorage(List<Long> freeStorage) {
		this.freeStorage = freeStorage;
	}
	
	/**
	 * Katya: Gets free BW.
	 * 
	 * @return free BW
	 */
	protected List<Long> getFreeBw() {
		return freeBw;
	}

	/**
	 * Katya: Sets free BW.
	 * 
	 * @param freeBW the new free BW
	 */
	protected void setFreeBW(List<Long> freeBw) {
		this.freeBw = freeBw;
	}
	
	/**
	 * Adds the ints of a list
	 * 
	 * @param list of ints
	 */	
	protected int sum (List<Integer> list) {
	    int sum = 0;
	    for (int i: list) {
	        sum += i;
	    }
	    return sum;
	}
	/**
	 * Adds the longs of a list
	 * 
	 * @param list of lons
	 */	
	protected Long sumLong (List<Long> list) {
	    long sum = 0;
	    for (Long i: list) {
	        sum += i;
	    }
	    return sum;
	}

}