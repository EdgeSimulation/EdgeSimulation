package org.cloudbus.cloudsim.examples.network.datacenter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.distributions.UniformDistr;
import org.cloudbus.cloudsim.examples.PrintFile_K;
import org.cloudbus.cloudsim.examples.power.Constants;
import org.cloudbus.cloudsim.examples.power.Helper;
import org.cloudbus.cloudsim.network.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.network.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.network.datacenter.RootSwitch;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerDatacenter;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerHost;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerHostUtilizationHistory;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicyMigrationAbstract;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicyMigrationInterQuartileRange;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicyMigrationLocalRegression;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicyMigrationLocalRegressionRobust;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicyMigrationMedianAbsoluteDeviation;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicyMigrationStaticThreshold;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmAllocationPolicySimple;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicy;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyMaximumCorrelation;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyMinimumMigrationTime;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyMinimumUtilization;
import org.cloudbus.cloudsim.network_power.datacenter.Network_PowerVmSelectionPolicyRandomSelection;
import org.cloudbus.cloudsim.power.PowerVm;
import org.cloudbus.cloudsim.network.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.network.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.network.datacenter.OptimVMAllocationPolicy_CommunityBased_LB_SC;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

public class Test_FatTree_Example_Power {
	/** The cloudlet list. */
	private static List<Cloudlet> cloudletList;

	/** The vmlist. */
	private static List<Vm> vmList;

	private static int Random_RAM_VMs (int cores){
	    //RAM: 2048, 4096 MB
		//noCPUs <= noRAMGB
	    Random randomGenerator = new Random();
	    int RAM = 0;
	    
	    int randomInt = randomGenerator.nextInt(2);
	    
	    if (randomInt == 0)
	    	  RAM = 4096;
	    else if (randomInt == 1)
	    	  RAM = 2048;
	    
	    return RAM;
	}
	
	private static int Random_cores_VMs (){	    
		//VM cores: 1, 2 cores		    
		Random randomGenerator = new Random();
		int cores = 0;
		    
		int randomInt = randomGenerator.nextInt(2);
	    cores = (int)Math.pow(2,(double)randomInt);
	    //Log.printLine("RAM: " + RAM);
	    return cores;
	}
	
	
	private static int Unif_Dist_VMs(int max){
	    //number VMs per CloudService: uniformly distributed in [1,10], [1,20] or [1,30]
	   	UniformDistr VM_dist = null;
	   	int VM = 0;
	   
	   //int randomInt = randomGenerator.nextInt(3);
	   	
	   	//Log.printLine("Número generado: " + randomInt);
	   	//VM_dist= new UniformDistr(1,((randomInt)+1)*10);
	   	VM_dist= new UniformDistr(1,max+1);
	   	VM=(int)VM_dist.sample();
	   	Log.printLine("VM number: " + VM);
	   	return VM;
	   	//return 3;
	}
	
	private static List<Vm> createVM(int userId, int vms, int idShift) {
		//Creates a container to store VMs. This list is passed to the broker later
		LinkedList<Vm> list = new LinkedList<Vm>();

		//VM Parameters
		long size = 10000; //image size
		int mips = Constants.HOST_MIPS;
		long bw = 100;
		String vmm = "Xen"; //VMM name
		int coresVM = 0;

		//create VMs
		Vm[] vm = new Vm[vms];
		for(int i = 0; i < vms; i++){
			coresVM = Random_cores_VMs();
			vm[i] = new PowerVm(idShift + i, userId, mips, coresVM , Random_RAM_VMs(coresVM), bw, size, 1, 
					vmm, new CloudletSchedulerSpaceShared(), Constants.SCHEDULING_INTERVAL);
			list.add(vm[i]);
		}

		return list;
	}


	private static List<Cloudlet> createCloudlet(int userId, int cloudlets, int idShift){
		// Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();
		//cloudlet parameters
		long length = 4000000;
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++){
			cloudlet[i] = new Cloudlet(idShift + i, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			// setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
		}

		return list;
	}

	
	
	
	/**
	 * Creates main() to run this example.
	 * 
	 * @param args
	 *            the args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {

		//Log.disable(); //.setOutput(_output);
		//Log.setOutput(_output);
		
		java.util.Date d = new java.util.Date();
		String arguments="";
		for (int i=0; i< args.length; i++)
			arguments=arguments+"_"+args[i];
		File file = new File("./log/cloudSim_K_Log_Log" + d.getTime() + arguments + ".txt");
		file.createNewFile();
		Log.setOutput(new FileOutputStream(file));
		Log.printLine("Starting CloudSimExample_K...");
		
		PrintFile_K.AddtoFile(arguments,"");					


		try {
			// First step: Initialize the CloudSim package. It should be called
			// before creating any entities.
			// args: [0] number of PMs		(54000 or 108000)
			//		 [1] type of PMs		(1 or 2)
			//		 [2] num_CloudServices 	(1000 or 2000)
			//		 [3] Max number of VMs per CS (10, 20 or 30)
			//		 [4] VM allocation policy (lb-lb, lb-sc, sc-lb, sc-sc, dvfs)
			//		 [5] VM migration policy (dvfs, iqr, mad, lr, lrr, thr)
			//		 [6] VM selection policy (mmt, mc, mu, rs, empty)
			
			
			int PMnumber = Integer.parseInt(args[0]); 	// number of PMs
			int hostType = Integer.parseInt(args[1]); 	// type of host (defines cpus, ram, mips, bw, storage)
			
			int num_CloudServices = Integer.parseInt(args[2]);  // number of cloud services
			int max_VMs = Integer.parseInt(args[3]); 	// Max. number of VMs per CS
			
			String allocate = args[4];  // allocation policy
			String migrate = args[5];   // migration policy
			String select = "";
			if (args.length == 7)
				select = args[6];    // selection policy
			
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = true;  // mean trace events

			int num_VMs = 0;
			int num_Total_VMs = 0;			
			String num_broker= "";

			// Initialize the CloudSim library
			CloudSim.init(num_CloudServices, calendar, trace_flag);

			// Second step: Create Datacenters
			// Datacenters are the resource providers in CloudSim. We need at
			// list one of them to run a CloudSim simulation
			@SuppressWarnings("unused")
			
			Network_PowerDatacenter datacenter0 = createDatacenter("Datacenter_0", PMnumber, hostType, allocate, migrate, select);
			datacenter0.setDisableMigrations(false);
			// Third step: Create Broker
			DatacenterBroker[] broker = new DatacenterBroker[num_CloudServices];
			
			for(int i=0;i<num_CloudServices;i++){
				num_broker = "Broker_" + i;
				broker[i] = createBroker(num_broker);
				int brokerId = broker[i].getId();
				
				num_VMs = Unif_Dist_VMs(max_VMs);
				//Fourth step: Create VMs and Cloudlets and send them to broker
									
				vmList = createVM(brokerId, num_VMs, 0); //creating VMs for the CLoudService
				cloudletList = createCloudlet(brokerId, num_VMs, 0); 
							
				broker[i].submitVmList(vmList);
				broker[i].submitCloudletList(cloudletList);
				
				num_Total_VMs = num_Total_VMs + num_VMs;
			}


			// Sixth step: Starts the simulation
			double lastClock = CloudSim.startSimulation();
			
			// Final step: Print results when simulation is over
			List<Cloudlet> newList = null;
			List<Vm> newListVms = null;
			newList = broker[0].getCloudletReceivedList();
			newListVms = broker[0].getVmList();
			
			for(int i=1;i<num_CloudServices;i++){
				newList.addAll(broker[i].getCloudletReceivedList());
				newListVms.addAll(broker[i].getVmList());
			}


			CloudSim.stopSimulation();

			String msg = "\n" + "number hosts  \t number cores per host \t number RAM per host \t number CS \t max VMs";// \t number used PMs";
			PrintFile_K.AddtoFile(arguments,msg);
			msg =  "\t" + PMnumber + "\t\t" + Constants.HOST_PES[hostType]+ "\t\t\t" +Constants.HOST_RAM[hostType] + "\t\t" + num_CloudServices + "\t\t" + 
					max_VMs + "\n";
			PrintFile_K.AddtoFile(arguments,msg);					
			
			//printCloudletList(arguments, newList,newListVms,datacenter0);

			Helper.printResults_1(
					datacenter0,
					vmList,
					lastClock,
					"PowerNet",
					Constants.OUTPUT_CSV,
					"./log/");

			Log.printLine("CloudSimExample_K finished!");

			
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}
	}

	/**
	 * Creates the datacenter.
	 * 
	 * @param name
	 *            the name
	 * 
	 * @return the datacenter
	 */
	private static Network_PowerDatacenter createDatacenter(String name, int PM_number, int hostType, String allocate, String migrate, String select) {

		
		int mips = Constants.HOST_MIPS;

		// Here are the steps needed to create a PowerDatacenter:
		// 1. We need to create a list to store
		// our machine

		List<Network_PowerHost> hostList = new ArrayList<Network_PowerHost>();

		// 2. A Machine contains one or more PEs or CPUs/Cores.
		// In this example, it will have only one core.
		List<Pe> peList = new ArrayList<Pe>();


		// 3. Create PEs and add these into a list.
		for(int i=0;i<Constants.HOST_PES[hostType];i++)
			peList.add(new Pe(i, new PeProvisionerSimple(mips)));

		// 4. Create Host with its id and list of PEs and add them to the list
		// of machines
		
		NetworkConstants.BandWidthEdgeHost=Constants.HOST_BW;

		//katya: creating the physical machines 
		for(int i=0;i<PM_number;i++){
			
			hostList.add(
	    			new Network_PowerHostUtilizationHistory(
	    				i,
	    				new RamProvisionerSimple(Constants.HOST_RAM[hostType]),
	    				new BwProvisionerSimple(Constants.HOST_BW),
	    				Constants.HOST_STORAGE,
	    				peList,
	    				//new VmSchedulerTimeShared(peList),
	    				new VmSchedulerSpaceShared(peList),
	    				Constants.HOST_POWER[hostType]
	    			)
	    		);
		}

		// 5. Create a DatacenterCharacteristics object that stores the
		// properties of a data center: architecture, OS, list of
		// Machines, allocation policy: time- or space-shared, time zone
		// and its price (G$/Pe time unit).
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this
		// resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are
		// not
		// adding
		// SAN
		// devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch,
				os,
				vmm,
				hostList,
				time_zone,
				cost,
				costPerMem,
				costPerStorage,
				costPerBw);

		// 6. Finally, we need to create a NetworkDatacenter object.
		Network_PowerDatacenter datacenter = null;
		try {
			VmAllocationPolicy cb_policy=getVmAllocationPolicy(allocate, hostList);
			VmAllocationPolicy mg_policy=getVmMigrationPolicy(migrate,select,"1",hostList); 
			datacenter = new Network_PowerDatacenter(
					name,
					characteristics,
					//new NetworkVmAllocationPolicy(hostList),
					cb_policy,
					mg_policy,
					storageList,
					Constants.SCHEDULING_INTERVAL);
			
			// Create Internal Datacenter network
			int ports_per_switch = 36;
			CreateNetwork(PM_number, datacenter, ports_per_switch);
			if (cb_policy.getClass().getName().equals("org.cloudbus.cloudsim.network.datacenter.OptimVMAllocationPolicy_CommunityBased_LB_SC"))
				((OptimVMAllocationPolicy_CommunityBased_LB_SC) cb_policy).createCommunities(PM_number,datacenter, ports_per_switch);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	public static VmAllocationPolicy getVmAllocationPolicy(
			String vmAllocationPolicyName,
			List<Network_PowerHost> hostList) {
		VmAllocationPolicy vmAllocationPolicy = null;
		String high="";
		String low="";

		if (vmAllocationPolicyName.equals("lb-lb")) {
			high="LB"; low="LB";
			vmAllocationPolicy = new OptimVMAllocationPolicy_CommunityBased_LB_SC(hostList, high, low);
		} else if (vmAllocationPolicyName.equals("lb-sc")) {
			high="LB"; low="SC";
			vmAllocationPolicy = new OptimVMAllocationPolicy_CommunityBased_LB_SC(hostList, high, low);
		} else if (vmAllocationPolicyName.equals("sc-lb")) {
			high="SC"; low="LB";
			vmAllocationPolicy = new OptimVMAllocationPolicy_CommunityBased_LB_SC(hostList, high, low);
		} else if (vmAllocationPolicyName.equals("sc-sc")) {
			high="SC"; low="SC";
			vmAllocationPolicy = new OptimVMAllocationPolicy_CommunityBased_LB_SC(hostList, high, low);
		} else  //(vmAllocationPolicyName.equals("dvfs")) {
			vmAllocationPolicy = new Network_PowerVmAllocationPolicySimple(hostList);
		return vmAllocationPolicy;
	}

	
	
	
	public static VmAllocationPolicy getVmMigrationPolicy(
			String vmAllocationPolicyName,
			String vmSelectionPolicyName,
			String parameterName,
			List<Network_PowerHost> hostList) {
		VmAllocationPolicy vmAllocationPolicy = null;
		Network_PowerVmSelectionPolicy vmSelectionPolicy = null;
		if (!vmSelectionPolicyName.isEmpty()) {
			vmSelectionPolicy = getVmSelectionPolicy(vmSelectionPolicyName);
		}
		double parameter = 0;
		if (!parameterName.isEmpty()) {
			parameter = Double.valueOf(parameterName);
		}
		if (vmAllocationPolicyName.equals("iqr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationInterQuartileRange(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("mad")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationMedianAbsoluteDeviation(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationLocalRegression(
					hostList,
					vmSelectionPolicy,
					parameter,
					Constants.SCHEDULING_INTERVAL,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lrr")) {
			Network_PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					1.0);
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationLocalRegressionRobust(
					hostList,
					vmSelectionPolicy,
					parameter,
					Constants.SCHEDULING_INTERVAL,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("thr")) {
			vmAllocationPolicy = new Network_PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					parameter);
		} else if (vmAllocationPolicyName.equals("dvfs")) {
			vmAllocationPolicy = new Network_PowerVmAllocationPolicySimple(hostList);
		} else {
			System.out.println("Unknown VM allocation policy: " + vmAllocationPolicyName);
			System.exit(0);
		}
		return vmAllocationPolicy;
	}

	
	/**
	 * Gets the vm selection policy.
	 * 
	 * @param vmSelectionPolicyName the vm selection policy name
	 * @return the vm selection policy
	 */
	public static Network_PowerVmSelectionPolicy getVmSelectionPolicy(String vmSelectionPolicyName) {
		Network_PowerVmSelectionPolicy vmSelectionPolicy = null;
		if (vmSelectionPolicyName.equals("mc")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyMaximumCorrelation(
					new Network_PowerVmSelectionPolicyMinimumMigrationTime());
		} else if (vmSelectionPolicyName.equals("mmt")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyMinimumMigrationTime();
		} else if (vmSelectionPolicyName.equals("mu")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyMinimumUtilization();
		} else if (vmSelectionPolicyName.equals("rs")) {
			vmSelectionPolicy = new Network_PowerVmSelectionPolicyRandomSelection();
		} else {
			System.out.println("Unknown VM selection policy: " + vmSelectionPolicyName);
			System.exit(0);
		}
		return vmSelectionPolicy;
	}

	
	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 * 
	 * @return the datacenter broker
	 */
	private static DatacenterBroker createBroker(String name) {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker(name);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}


	static void CreateNetwork(int numhost, NetworkDatacenter dc, int ports_per_switch) {

		// create 3 level FatTree
		NetworkConstants.EdgeSwitchPort=ports_per_switch;
		NetworkConstants.AggSwitchPort=ports_per_switch;
		NetworkConstants.RootSwitchPort=ports_per_switch;
		
		// number of switches
		NetworkConstants.EDGE_LEVEL=(int) Math.ceil(numhost/(ports_per_switch/2.0));
		NetworkConstants.Agg_LEVEL=NetworkConstants.EDGE_LEVEL;
		NetworkConstants.ROOT_LEVEL=(int) Math.ceil(NetworkConstants.Agg_LEVEL/2.0);

		// core switches
		RootSwitch coreswitch[] = new RootSwitch[NetworkConstants.ROOT_LEVEL];
		for (int i = 0; i < NetworkConstants.ROOT_LEVEL; i++) {
			coreswitch[i] = new RootSwitch("Core" + i, NetworkConstants.ROOT_LEVEL, dc);
			dc.Switchlist.put(coreswitch[i].getId(), coreswitch[i]);
		}

		// aggregation switches
		AggregateSwitch aggswitch[] = new AggregateSwitch[NetworkConstants.Agg_LEVEL];
		int index=0;
		for (int i = 0; i < NetworkConstants.Agg_LEVEL; i++) {
			aggswitch[i] = new AggregateSwitch("Aggregate" + i, NetworkConstants.Agg_LEVEL, dc);
			for (int j=0; j<ports_per_switch/2; j++){
				aggswitch[i].uplinkswitches.add(coreswitch[index]);
				coreswitch[index].downlinkswitches.add(aggswitch[i]);
				if (index==NetworkConstants.ROOT_LEVEL-1){
					index=0;
				}else index++;
			}
			dc.Switchlist.put(aggswitch[i].getId(), aggswitch[i]);
		}
		
		// Edge Switch
		EdgeSwitch edgeswitch[] = new EdgeSwitch[NetworkConstants.EDGE_LEVEL];
		for (int i = 0; i < NetworkConstants.EDGE_LEVEL; i++) {
			edgeswitch[i] = new EdgeSwitch("Edge" + i, NetworkConstants.EDGE_LEVEL, dc);
			for (int j=0; j<NetworkConstants.Agg_LEVEL; j++){
				edgeswitch[i].uplinkswitches.add(aggswitch[j]);
				aggswitch[j].downlinkswitches.add(edgeswitch[i]);
			}
			dc.Switchlist.put(edgeswitch[i].getId(), edgeswitch[i]);
		}

		// attach hosts
		for (Host hs : dc.getHostList()) {
//			hs1.bandwidth = NetworkConstants.BandWidthEdgeHost;
			int switchnum = (int) (hs.getId() / (NetworkConstants.EdgeSwitchPort/2));
//			edgeswitch[switchnum].hostlist.put(hs.getId(),(NetworkHost) hs);
			dc.HostToSwitchid.put(hs.getId(), edgeswitch[switchnum].getId());
//			hs1.sw = edgeswitch[switchnum];
//			List<Host> hslist = hs1.sw.fintimelistHost.get(0D);
//			if (hslist == null) {
//				hslist = new ArrayList<Host>();
//				hs1.sw.fintimelistHost.put(0D, hslist);
//			}
//			hslist.add(hs1);

		}

	}
	private static void printCloudletList(String arguments, List<Cloudlet> list, List<Vm> listVm, Network_PowerDatacenter DC_host) {
		int size = list.size();
		Cloudlet cloudlet;
		//katya
		Vm vm = null;
		List<Vm> listVm_brkr =  new ArrayList<Vm>();
		int brokr = 0;
		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent +
				"Data center ID" + indent + "VM ID" + indent + indent + "Time" + indent + "Start Time" + indent + "Finish Time");
		PrintFile_K.AddtoFile(arguments,"BrokerId - VM ID" + indent + "Cloudlet ID" + indent + indent + "VM RAM" + indent + indent + "VMcores" + 
				indent + indent + "VM MIPS" + indent + indent + "VMsize" + indent + indent + "HOST");
		
		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS){
				Log.print("SUCCESS");

				brokr = cloudlet.getUserId() - 3;
				Iterator<Vm> VmIterator = listVm.iterator();
				while (VmIterator.hasNext()) {
					vm = VmIterator.next();	
					if (vm.getUserId() == brokr + 3)
						listVm_brkr.add(vm);
				}
				if (!listVm_brkr.isEmpty()) { 
					
					vm =  listVm_brkr.get(cloudlet.getVmId());
				
					Log.printLine( indent + indent + cloudlet.getResourceId() + indent + indent + indent + brokr +"-"+ cloudlet.getVmId() +
						indent + indent + indent + dft.format(cloudlet.getActualCPUTime()) +
						indent + indent + dft.format(cloudlet.getExecStartTime())+ indent + indent + indent + dft.format(cloudlet.getFinishTime()));
				
					PrintFile_K.AddtoFile(arguments,indent + brokr + "-" + vm.getId() + " " + // vm.getUserId() +//+ vm.getUid() +
						indent + indent + indent + indent + cloudlet.getCloudletId()+
						indent + indent + indent +  vm.getRam() + indent + indent + indent + vm.getNumberOfPes() + 
						indent + indent + indent + vm.getMips() + indent + indent + indent + vm.getSize());
				}
				listVm_brkr.clear();
			}
		}

	}


}