package org.cloudbus.cloudsim.examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//Katya
import java.util.Iterator;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
//import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.core.CloudSim;
//Katya: para acceder a la lista de VMs
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.core.SimEntity;

/* Algorithm Vector Based Load Balancing:
 * 
/**
 * Optimisation based {@link Vm} allocation policy.
 * 
 * (copiado de la clase RoundRobinVmAllocationPolicy.java)
 * 
 * @author Katja Gilly
 */
public class OptimVmAllocationPolicy_VectorBasedLoadBalancing_perbroker extends org.cloudbus.cloudsim.VmAllocationPolicy {
	
	private static final boolean FALSE = false;

	/** Katya: Indicates if it is the first call to the allocation policy **/
	private int ini=0;

	/** The vm table. */
	private Map<String, Host> vmTable;

	/** Katya: The requested vm list. */
	private List<Vm> ALLvmList = null;

	/** The used pes. */
	private Map<String, Integer> usedPes;

	/** The free pes. */
	private List<Integer> freePes;

	/** Katya: Free RAM. */
	private List<Integer> freeRam;
	
	/** Katya: Used BW. */
	private Map<String, Long> usedBw;
	
	/** Katya: Free BW. */
	private List<Long> freeBw;
	
	
	private final Map<String, Host> vm_table = new HashMap<String, Host>();
	
	private enum UL{
		LOW, MEDIUM, HIGH
	}
	
	private List<UL> utilizationLevel=new ArrayList <UL>();
	
	private double high=0.75, medium=0.25;
	
	public OptimVmAllocationPolicy_VectorBasedLoadBalancing_perbroker(List<? extends Host> list) {
		super(list);
		setFreePes(new ArrayList<Integer>());
		setFreeRAM(new ArrayList<Integer>());		//Katya
		setFreeBW(new ArrayList<Long>());			//Katya
		for (Host host : getHostList()) {
			getFreePes().add(host.getNumberOfPes());
			getFreeRam().add(host.getRam());
			getFreeBw().add(host.getBw());
		}

		setVmTable(new HashMap<String, Host>());
		setUsedPes(new HashMap<String, Integer>());
		
	}
	
	protected class Vector{
		private float pes=0,ram=0,bw=0;
		
		public Vector(float p, float r, float b){
			pes=p;	ram=r;	bw=b;
		}
		void setPes(float v){pes=v;}
		void setRam(float v){ram=v;}
		void setBw(float v){bw=v;}
		
		float getPes(){return pes;}
		float getRam(){return ram;}
		float getBw(){return bw;}
		
		float max(){
			return Math.max(Math.max(pes,ram),bw);
		}
		
		double magnitude(){
			return Math.sqrt(pes*pes+ram*ram+bw*bw);
		}
		
		double sum(Vector v){
			Vector s=new Vector(pes+v.pes,ram+v.ram,bw+v.bw);
			return s.magnitude();
		}
	}
	
	protected Vector computeRUV (Host esteHost, int i) {
		
		return	new Vector(
					(float)(esteHost.getNumberOfPes()-getFreePes().get(i))/esteHost.getNumberOfPes(),
					(float)(esteHost.getRam()-getFreeRam().get(i))/esteHost.getRam(),
					((long)esteHost.getBw()-getFreeBw().get(i))/esteHost.getBw()
					);
	}
/*	
	protected List<Vector> computeRCV (List<Host> HostList) {
		
		Host esteHost = null;
		if (RCV.size()==0)
			for (int i=0; i < HostList.size(); i++) {
				esteHost = HostList.get(i);
				RCV.add(new Vector(
					(float)esteHost.getNumberOfFreePes()/esteHost.getNumberOfPes(),
					(float)getFreeRam().get(i)/esteHost.getRam(),
					(long)getFreeBw().get(i)/esteHost.getBw()
				));
			}
		else
			for (int i=0; i < HostList.size(); i++) {
				esteHost = HostList.get(i);
				RCV.get(i).setPes((float)esteHost.getNumberOfFreePes()/esteHost.getNumberOfPes());
				RCV.get(i).setRam((float)getFreeRam().get(i)/esteHost.getRam());
				RCV.get(i).setBw((long)getFreeBw().get(i)/esteHost.getBw());
			}
		return RCV;
	}
*/
	protected Vector computeRRV (Vm esteVm, Host target) {
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes(),
				(float)esteVm.getRam()/target.getRam(),
				(long)esteVm.getBw()/target.getBw()
			);
	}

	protected Vector computeRIVpm (Host esteHost, int i) {
		
		float sum=((float)(esteHost.getNumberOfPes()-getFreePes().get(i))/esteHost.getNumberOfPes() +
				(float)(esteHost.getRam()-getFreeRam().get(i))/esteHost.getRam() +
				((long)esteHost.getBw()-getFreeBw().get(i))/esteHost.getBw())/3;
		 return new Vector( 
				(float)(esteHost.getNumberOfPes()-getFreePes().get(i))/esteHost.getNumberOfPes() - sum,
				(float)(esteHost.getRam()-getFreeRam().get(i))/esteHost.getRam() - sum,
				((long)esteHost.getBw()-getFreeBw().get(i))/esteHost.getBw() - sum
			);
	}
	
	protected Vector computeRIVvm (Vm esteVm, Host target) {
		
		float sum=((float)esteVm.getNumberOfPes()/target.getNumberOfPes() +
					(float)esteVm.getRam()/target.getRam() +
					(long)esteVm.getBw()/target.getBw())/3;
		 return new Vector(
				(float)esteVm.getNumberOfPes()/target.getNumberOfPes() - sum,
				(float)esteVm.getRam()/target.getRam() - sum,
				(long)esteVm.getBw()/target.getBw() - sum
			);
	}
	
	protected int VMtriangle(Vm vm, Host target){
		// return the triangle in which vm's RRV lies
		Vector RRV=computeRRV(vm,target);
		
		if (RRV.pes >= RRV.ram){ 
			if (RRV.ram >= RRV.bw)
				return 5; //CM
			else if (RRV.pes >= RRV.bw)
					return 0; //CI
		} 
		if (RRV.ram >= RRV.pes){ 
			if (RRV.pes >= RRV.bw)
				return 4; //MC
			else if (RRV.ram >= RRV.bw)
				return 3; //MI
		}
		if (RRV.bw >= RRV.pes){
			if (RRV.pes >= RRV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected int CRT(int T){
		// return the CRT triangle of triangle T
		if (T==0) return 3;
		else if (T==1) return 4;
		else if (T==2) return 5;
		else if (T==3) return 0;
		else if (T==4) return 1;
		else if (T==5) return 2;
		else return -1;
	}
	
	protected List<Integer> firstTneighbor(int t){
		if (t==0) return Arrays.asList(5,1);
		else if (t==1) return Arrays.asList(2,0);
		else if (t==2) return Arrays.asList(1,3);
		else if (t==3) return Arrays.asList(2,4);
		else if (t==4) return Arrays.asList(3,5);
		else if (t==5) return Arrays.asList(0,4);
		else return Arrays.asList(-1,-1);
	}
	
	protected List<Integer> secondTneighbor(int t){
		if (t==0) return Arrays.asList(4,2);
		else if (t==1) return Arrays.asList(3,5);
		else if (t==2) return Arrays.asList(0,4);
		else if (t==3) return Arrays.asList(1,5);
		else if (t==4) return Arrays.asList(2,0);
		else if (t==5) return Arrays.asList(1,3);
		else return Arrays.asList(-1,-1);
	}
	
	protected int PMtriangle(Host target, int i){
		// return the triangle in which PM's RUV lies
		Vector RUV=computeRUV(target,i);
		
		if (RUV.pes >= RUV.ram){ 
			if (RUV.ram >= RUV.bw)
				return 5; //CM
			else if (RUV.pes >= RUV.bw)
					return 0; //CI
		} 
		if (RUV.ram >= RUV.pes){ 
			if (RUV.pes >= RUV.bw)
				return 4; //MC
			else if (RUV.ram >= RUV.bw)
				return 3; //MI
		}
		if (RUV.bw >= RUV.pes){
			if (RUV.pes >= RUV.ram)
				return 1; //IC
			else return 2; //IM
		}
		// should never happen
		return -1;
	}
	
	protected List<UL> getOverallPMUtilization(List<Host> HostList){
//		1: if max(CPU;MEM; IO) >= HIGH then
//		2: Utilization level is HIGH;
//		3: else if max(CPU;MEM; IO) >= MEDIUM then
//		4: Utilization level is MEDIUM;
//		5: else
//		6: Utilization level is LOW;
//		7: end if
		if (utilizationLevel.size()==0)
			for (int i=0; i < HostList.size(); i++) {
				Vector RUV=computeRUV(HostList.get(i),i);
				if (RUV.max() >= high)
						utilizationLevel.add(UL.HIGH);
				else if (RUV.max() >= medium)
						utilizationLevel.add(UL.MEDIUM);
				else utilizationLevel.add(UL.LOW);
			}
		else
			for (int i=0; i < HostList.size(); i++) {
				Vector RUV=computeRUV(HostList.get(i),i);
				if (RUV.max() >= high)
						utilizationLevel.set(i, UL.HIGH);
				else if (RUV.max() >= medium)
						utilizationLevel.set(i, UL.MEDIUM);
				else utilizationLevel.set(i, UL.LOW);
			}
		return utilizationLevel;
	}
	
	public Host dynamicVMplacement (List<Host> HostList, Vm vm) {
//	1: PotentialPMlist   GetPotentialPMs(VM; goal);
//	2: if PotentialPMlist empty then
//	3: Introduce new PM;
//	4: end if
//	5: for all PM in PotentialPMlist do
//	6: Compute the vector addition of RIVs of PM and VM;
//	7: M   magnitude of the above addition vector;
//	8: end for
//	9: Mark PM with the lowest M as the host for the VM;
		
		List<Host> potentialPMlist=getPotentialPMsLB(vm,HostList);
		if (potentialPMlist.size()==0)
		{	//find a new PM with all resources intact
			for (int i=0; i < HostList.size(); i++){
				Host host=HostList.get(i);
				Vector RUV=computeRUV(host,i);
				if (RUV.magnitude()==0)
				{
					potentialPMlist.add(host);
					break;
				}
			}
		}
		if (potentialPMlist.size()==0) // no available PM
			return null;
		
		List<Double> M = new ArrayList<>();
		for (int i=0; i<potentialPMlist.size(); i++)
		{
			Host host=potentialPMlist.get(i);
			int index=HostList.indexOf(host);
			Vector RIVpm=computeRIVpm(host,index);
			Vector RIVvm=computeRIVvm(vm,host);
			M.add(RIVpm.sum(RIVvm));
		}
		// find PM with lowest M
			double minM=M.get(0);
			int minIndex=0;
			for (int i=1; i<M.size(); i++){
				if (minM>M.get(i)){
					minM=M.get(i);
					minIndex=i;
				}
			}
		// place VM on this host
			boolean allocated = 														// Pack the biggest feasible item into bin
					allocateHostForVm(vm, potentialPMlist.get(minIndex));
			if (allocated) {
				//update used resources of host
				getUsedPes().put(vm.getUid(),
						vm.getNumberOfPes());
				Host theHost=potentialPMlist.get(minIndex);
				int who = HostList.indexOf(theHost);
				getFreePes().set(who, getFreePes().get(theHost.getId()) - vm.getNumberOfPes());
				getFreeRam().set(who, getFreeRam().get(theHost.getId()) - vm.getCurrentAllocatedRam());
				getFreeBw().set(who, getFreeBw().get(theHost.getId()) - vm.getCurrentAllocatedBw());

				int brkr = vm.getUserId()-3;
				PrintFile_K.AddtoFile("",CloudSim.clock() + ":\t\t\t" + 
						theHost.getId() + "\t\t\t" +  
						HostList.get(HostList.indexOf(theHost)).getVmList().size() +
						"\t\t\t" +  brkr + "-" + vm.getId() + 
						"\t\t\t" + vm.getRam() +
						"\t\t\t" + vm.getNumberOfPes() + 
						"\t\t\t" + vm.getMips());
				return HostList.get(who);
			}
			else return null;
	}
	
	protected List<Host> getPotentialPMsLB(Vm vm, List<Host> hostList){
//		2: T = CRT of the triangle in which the VM lies;
//		3: PotentialPMlist  ;;
//		5: /* start from LOW util to HIGH util as shown in Figure 9*/
//		6: PotentialPMlist   fPMs in T which have LOW utilizationg;
//		7: Remove PMs from PotentialPMlist which can not support the VM;
//		8: if PotentialPMlist= ; then
//			9: PotentialPMlist fPMs in T which have MEDIUM
//				utilizationg[fPMs in T’s two first order neighbors which
//				have LOW utilizationg;
//			10: Remove PMs from PotentialPMlist which can not support the VM;
//		11: end if
//		12: if PotentialPMlist= ; then
//			13: PotentialPMlist fPMs in T which have HIGH
//				utilizationg[fPMs in T’s two first order neighbors which
//				have MEDIUM utilizationg[fPMs in T’s two second order
//				neighbors which have LOW utilizationg;
//			14: Remove PMs from PotentialPMlist which can not support the VM;
//		15: end if
//		29: if PotentialPMlist is Empty then
//			30: put all the PMs which were not checked above into PotentialPMlist;
//			31: Remove PMs from PotentialPMlist which can not support the VM;
//		32: end if
//		33: return PotentialPMlist;
		List<Host> potentialPMlist = new ArrayList<Host>();
		List<UL> ul=getOverallPMUtilization(hostList);
		
		//LOW
		for (int i=0; i < hostList.size(); i++){
			// find all PMs that have tVM=tPM
			Host host=hostList.get(i);
			// if host empty of host full skip
			if (computeRUV(host,i).magnitude()==0) continue;
			if (computeRUV(host,i).getBw()==1) continue;
			if (computeRUV(host,i).getPes()==1) continue;
			if (computeRUV(host,i).getRam()==1) continue;
			int tVM=CRT(VMtriangle(vm,host)); // see row 6
			int tPM=PMtriangle(host,i); 
			if (tVM==tPM){
				if (ul.get(i)==UL.LOW)
					// check if PM has enough resources to host the VM
					if (host.isSuitableForVm(vm))
						potentialPMlist.add(host);
			}
		}
		
		//MEDIUM
		if (potentialPMlist.size()==0){
			for (int i=0; i < hostList.size(); i++){
				// find all PMs that have tVM=tPM
				Host host=hostList.get(i);
				// if host empty of host full skip
				if (computeRUV(host,i).magnitude()==0) continue;
				if (computeRUV(host,i).getBw()==1) continue;
				if (computeRUV(host,i).getPes()==1) continue;
				if (computeRUV(host,i).getRam()==1) continue;
				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host,i); 
				if (tVM==tPM){
					if (ul.get(i)==UL.MEDIUM)
						// check if PM has enough resources to host the VM
						if (host.isSuitableForVm(vm))
							potentialPMlist.add(host);
				}
				else{
					// two first T neighbors with LOW
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							if (host.isSuitableForVm(vm))
								potentialPMlist.add(host);
					}
				}
			}
		}
		
		//HIGH
		if (potentialPMlist.size()==0){
			for (int i=0; i < hostList.size(); i++){
				// find all PMs that have tVM=tPM
				Host host=hostList.get(i);
				// if host empty of host full skip
				if (computeRUV(host,i).magnitude()==0) continue;
				if (computeRUV(host,i).getBw()==1) continue;
				if (computeRUV(host,i).getPes()==1) continue;
				if (computeRUV(host,i).getRam()==1) continue;
				int tVM=CRT(VMtriangle(vm,host)); // see row 6
				int tPM=PMtriangle(host,i); 
				if (tVM==tPM){
					if (ul.get(i)==UL.HIGH)
						// check if PM has enough resources to host the VM
						if (host.isSuitableForVm(vm))
							potentialPMlist.add(host);
				}
				else{
					// two first T neighbors with MEDIUM
					if (firstTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.MEDIUM)
							if (host.isSuitableForVm(vm))
								potentialPMlist.add(host);
					}
					// two second T neighbors with LOW
					if (secondTneighbor(tVM).contains(tPM)){
						if (ul.get(i)==UL.LOW)
							if (host.isSuitableForVm(vm))
								potentialPMlist.add(host);
					}
				}
			}
		}
		
		// everything else
		if (potentialPMlist.size()==0){
			for (int i=0; i < hostList.size(); i++){
				// find all PMs that have tVM=tPM
				Host host=hostList.get(i);
				// if host empty of host full skip
				if (computeRUV(host,i).magnitude()==0) continue;
				if (computeRUV(host,i).getBw()==1) continue;
				if (computeRUV(host,i).getPes()==1) continue;
				if (computeRUV(host,i).getRam()==1) continue;
				if (host.isSuitableForVm(vm))
					potentialPMlist.add(host);
			}
		}
		
		return potentialPMlist;
	}
	
	public List<Map<String, Host>> INIoptimizeAllocation_vectorbased_loadbalancing (List<Host> HostList, List<Vm> Vmlist) {
							
		PrintFile_K.AddtoFile("","Timestamp" +"\t\t"+ "Host ID" +"\t\t" + "no. of VMs" + "\t\t" + "VM list (CS no. - VM no.)" + "\t\t" +
				"VM RAM" +  "\t\t" + "VMcores" + "\t\t" + "VM MIPS" + "\t\t" + "VMsize");

		for (int i=0; i < Vmlist.size(); i++){
			Host host=dynamicVMplacement(HostList,Vmlist.get(i));
			if (host==null){
				// placement failed
				// cloud service failed
				break;
			}
		}
		return null;
	}

	@Override
	public boolean allocateHostForVm(Vm vm) {
		if (this.vm_table.containsKey(vm.getUid())) {
			return true;
		}

		boolean vm_allocated = false;
		DatacenterBroker tempBroker = null;
		//Katya
		//Host host = getHostList().get(0);
		Iterator<SimEntity> entityIterator = CloudSim.getEntityList().iterator();
		// Let's find the broker
		while (entityIterator.hasNext()) {
			SimEntity tempEntity= entityIterator.next();
			//System.out.println("Entity's name: " + tempEntity.getName());
			if (tempEntity.getId() ==  vm.getUserId()) {
				tempBroker = (DatacenterBroker)CloudSim.getEntity(tempEntity.getName());
				//System.out.println("Add VMs of " + tempBroker.getName() + ": " + tempBroker.getVmList().size());
				ALLvmList = tempBroker.getVmList();
				break;
			}
		}
		
		this.INIoptimizeAllocation_vectorbased_loadbalancing (getHostList(),ALLvmList);
			
		if (vm.getHost()!=null) {
			vm_allocated = true;
		}			
		
		return vm_allocated;
	}

	@Override
	public boolean allocateHostForVm(Vm vm, Host host) 
	{
		int brkr = 0;
		if (host != null && host.vmCreate(vm)) 
		{
			vm_table.put(vm.getUid(), host);
			brkr = vm.getUserId()-3;
			Log.formatLine("%.4f:" + "CS #" + brkr + " - VM #" + vm.getId() + " has been allocated to the host#" + host.getId() + 
					" datacenter #" + host.getDatacenter().getId() + "(" + host.getDatacenter().getName() + ") #", 
					CloudSim.clock());
			return true;
		}
		return false;
	}

	@Override
	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) {
		return null;
	}

	@Override
	public void deallocateHostForVm(Vm vm) {
		Host host = this.vm_table.remove(vm.getUid());

		if (host != null) {
			host.vmDestroy(vm);
		}
	}

	@Override
	public Host getHost(Vm vm) {
		return this.vm_table.get(vm.getUid());
	}

	@Override
	public Host getHost(int vmId, int userId) {
		return this.vm_table.get(Vm.getUid(userId, vmId));
	}
	
	/**
	 * Gets the vm table.
	 * 
	 * @return the vm table
	 */
	public Map<String, Host> getVmTable() {
		return vmTable;
	}

	/**
	 * Sets the vm table.
	 * 
	 * @param vmTable the vm table
	 */
	protected void setVmTable(Map<String, Host> vmTable) {
		this.vmTable = vmTable;
	}

	/**
	 * Gets the used pes.
	 * 
	 * @return the used pes
	 */
	protected Map<String, Integer> getUsedPes() {
		return usedPes;
	}

	/**
	 * Sets the used pes.
	 * 
	 * @param usedPes the used pes
	 */
	protected void setUsedPes(Map<String, Integer> usedPes) {
		this.usedPes = usedPes;
	}

	/**
	 * Gets the free pes.
	 * 
	 * @return the free pes
	 */
	protected List<Integer> getFreePes() {
		return freePes;
	}

	/**
	 * Sets the free pes.
	 * 
	 * @param freePes the new free pes
	 */
	protected void setFreePes(List<Integer> freePes) {
		this.freePes = freePes;
	}
	
	/**
	 * Katya: Gets free RAM.
	 * 
	 * @return free RAM
	 */
	protected List<Integer> getFreeRam() {
		return freeRam;
	}

	/**
	 * Sets  free RAM.
	 * 
	 * @param freeRAM the new free RAM
	 */
	protected void setFreeRAM(List<Integer> freeRam) {
		this.freeRam = freeRam;
	}
	
	
	/**
	 * Katya: Gets free BW.
	 * 
	 * @return free BW
	 */
	protected List<Long> getFreeBw() {
		return freeBw;
	}

	/**
	 * Katya: Sets free BW.
	 * 
	 * @param freeBW the new free BW
	 */
	protected void setFreeBW(List<Long> freeBw) {
		this.freeBw = freeBw;
	}
	
	/**
	 * Adds the ints of a list
	 * 
	 * @param list of ints
	 */	
	protected int sum (List<Integer> list) {
	    int sum = 0;
	    for (int i: list) {
	        sum += i;
	    }
	    return sum;
	}
	/**
	 * Adds the longs of a list
	 * 
	 * @param list of lons
	 */	
	protected Long sumLong (List<Long> list) {
	    long sum = 0;
	    for (Long i: list) {
	        sum += i;
	    }
	    return sum;
	}

}