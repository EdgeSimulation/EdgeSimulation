package org.cloudbus.cloudsim.examples.power;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerDynamicWorkload;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.distributions.UniformDistr;
import org.cloudbus.cloudsim.power.PowerDatacenter;
import org.cloudbus.cloudsim.power.PowerVm;

public class PowerExample extends RunnerAbstract {

	public PowerExample(boolean enableOutput, boolean outputToFile, String inputFolder, String outputFolder,
			String workload, String vmAllocationPolicy, String vmSelectionPolicy, String parameter) {
		super(enableOutput, outputToFile, inputFolder, outputFolder, workload, vmAllocationPolicy, vmSelectionPolicy,
				parameter);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void init(String inputFolder) {
		// TODO Auto-generated method stub


	}
	
	
	private static int Random_RAM_VMs (int cores){
	    //RAM: 2048, 4096 or 8192 (MB)
		//noCPUs <= noRAMGB
	    Random randomGenerator = new Random();
	    int RAM = 0;
	    
	    int randomInt = randomGenerator.nextInt(3);
	    if (cores == 4) randomInt = randomGenerator.nextInt(2);
	    //Log.printLine("randomInt: " + randomInt);

	    if (randomInt == 0)
	    	  RAM = 8192;
	    else if (randomInt == 1)
	    	  RAM = 4096;
	    else if (randomInt == 2)
	    	  RAM = 2048;
	    //Log.printLine("RAM: " + RAM);
	    return RAM;
	}
	
	private static int Random_cores_VMs (){	    
		//VM cores: 1, 2 or 4 cores		    
		Random randomGenerator = new Random();
		int cores = 0;
		    
		int randomInt = randomGenerator.nextInt(3);
	    cores = (int)Math.pow(2,(double)randomInt);
	    //Log.printLine("RAM: " + RAM);
	    return cores;
	}
	
	
	private static int Unif_Dist_VMs(int max){
	    //number VMs per CloudService: uniformly distributed in [1,10], [1,20] or [1,30]
	   	UniformDistr VM_dist = null;
	   	int VM = 0;
	   
	   //int randomInt = randomGenerator.nextInt(3);
	   	
	   	//Log.printLine("Número generado: " + randomInt);
	   	//VM_dist= new UniformDistr(1,((randomInt)+1)*10);
	   	VM_dist= new UniformDistr(1,max+1);
	   	VM=(int)VM_dist.sample();
	   	Log.printLine("VM number: " + VM);
	   	return VM;
	   	//return 3;
	}
	
	private static List<Vm> createVM(int userId, int vms, int idShift) {
		//Creates a container to store VMs. This list is passed to the broker later
		LinkedList<Vm> list = new LinkedList<Vm>();

		//VM Parameters
		long size = 10000; //image size
		int mips = 1000;
		long bw = 1000;
		String vmm = "Xen"; //VMM name
		int coresVM = 0;

		//create VMs
		Vm[] vm = new Vm[vms];
		for(int i = 0; i < vms; i++){
			coresVM = Random_cores_VMs();
			vm[i] = new PowerVm(idShift + i, userId, mips, coresVM , Random_RAM_VMs(coresVM), bw, size, 1, 
					vmm, new CloudletSchedulerDynamicWorkload(mips, coresVM), Constants.SCHEDULING_INTERVAL);
			list.add(vm[i]);
		}

		return list;
	}


	private static List<Cloudlet> createCloudlet(int userId, int cloudlets, int idShift){
		// Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();
		//cloudlet parameters
		long length = 4000000;
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++){
			cloudlet[i] = new Cloudlet(idShift + i, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			// setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
		}

		return list;
	}

	
	
	public static void main(String[] args) throws IOException {
		
		Log.disable(); //.setOutput(_output);
		java.util.Date d = new java.util.Date();
		File file = new File("./log/cloudSim_K_Log" + d.getTime() + ".txt");
		file.createNewFile();
		Log.setOutput(new FileOutputStream(file));
		Log.printLine("Starting CloudSimExample_K...");

		try {
			// First step: Initialize the CloudSim package. It should be called
			// before creating any entities.
			// args: [0] num_CloudServices 	(1000, 2000 or 4000))
			//		 [1] number of PMs		(54000 or 108000)
			//		 [2] number of PM cores or Pes (8 or 16)
			//		 [3] GBs of RAM			(16 or 32)
			// 		 [4] Max number of VMs per CS (10, 20 or 30)
			int num_user =  Integer.parseInt(args[0]);  // number of grid users 
			int num_CloudServices = num_user;
			int PMnumber = Integer.parseInt(args[1]); 	// number of PMs
			int PMcores = Integer.parseInt(args[2]); 	// number of cores per PM
			int RAM = Integer.parseInt(args[3]); 		// GBs of RAM
			int max_VMs = Integer.parseInt(args[4]); 	// Max. number of VMs per CS
			boolean trace_flag = true;  // mean trace events

			int num_VMs = 0;
			int num_Total_VMs = 0;			
			String num_broker= "";

			String outputFolder = "./log/";
			String inputFolder = "";
			String workload = ""; 
			String vmAllocationPolicyName = "lr";
			String vmSelectionPolicyName = "mmt"; 
			String parameter = "";
			
			PowerExample pe = new PowerExample(true, true, inputFolder, outputFolder, workload, vmAllocationPolicyName, vmSelectionPolicyName,parameter);

			pe.init(inputFolder);
	
			try {
				CloudSim.init(1, Calendar.getInstance(), false);
							
				pe.hostList = Helper.createHostList(PMnumber, PMcores, RAM);
				
				pe.datacenter = (PowerDatacenter) Helper.createDatacenter(
						"Datacenter",
						PowerDatacenter.class,
						pe.hostList,
						pe.getVmAllocationPolicy(vmAllocationPolicyName, vmSelectionPolicyName, parameter));

				pe.datacenter.setDisableMigrations(false);
				
				// Third step: Create Broker
				pe.broker = new DatacenterBroker[num_CloudServices];
				
				for(int i=0;i<num_CloudServices;i++){
					num_broker = "Broker_" + i;
					pe.broker[i] = Helper.createBroker(num_broker);
					int brokerId = pe.broker[i].getId();
					
					num_VMs = Unif_Dist_VMs(max_VMs);
					//Fourth step: Create VMs and Cloudlets and send them to broker
										
					pe.vmList = createVM(brokerId, num_VMs, 0); //creating VMs for the CLoudService
					pe.cloudletList = createCloudlet(brokerId, num_VMs, 0); 
								
					pe.broker[i].submitVmList(pe.vmList);
					pe.broker[i].submitCloudletList(pe.cloudletList);
					
					num_Total_VMs = num_Total_VMs + num_VMs;
				}

				
	/*
				broker = Helper.createBroker();
				int brokerId = broker.getId();
				cloudletList = PlanetLabHelper.createCloudletListPlanetLab(brokerId, inputFolder);
				vmList = Helper.createVmList(brokerId, cloudletList.size());
				hostList = Helper.createHostList(PlanetLabConstants.NUMBER_OF_HOSTS);
	*/
			} catch (Exception e) {
				e.printStackTrace();
				Log.printLine("The simulation has been terminated due to an unexpected error");
				System.exit(0);
			}

			
			pe.start(pe.getExperimentName(workload, vmAllocationPolicyName, vmSelectionPolicyName, parameter),
					outputFolder,
					pe.getVmAllocationPolicy(vmAllocationPolicyName, vmSelectionPolicyName, parameter), num_CloudServices);
	
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}

		
	}

}
